package survey.nic.utility;

/**
 * Created by Ravi on 9/10/2016.
 */
public class Test {
    public static void main(String ar[]){
        String password= Util.MD5("test@123");
        System.out.println("Conversion1===="+password);
        java.util.Random rng = new java.util.Random(); //Provide a seed if you want the same ones every time
        final long first14 =5156782556679996L; //(rng.nextLong() % 100000000000000L) + 5200000000000000L;
        System.out.println("Number===="+first14);
        final String againPassword=Util.MD5(first14+"" + "" + password);
        System.out.println("Conversion2===="+againPassword);
    }
}
