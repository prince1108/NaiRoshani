package survey.nic.com.survey;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;

import survey.nic.utility.Util;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread lTimer = new Thread() {
            public void run() {
                try {
                    int lTimer1 = 0;
                    while (lTimer1 < 5000) {
                        sleep(100);
                        lTimer1 = lTimer1 + 100;
                    }
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    if (Util.getUid(SplashActivity.this)!=null&&!Util.getUid(SplashActivity.this).equalsIgnoreCase(""))
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    else {
                        startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    finish();
                }
            }
        };
        lTimer.start();
    }
}
