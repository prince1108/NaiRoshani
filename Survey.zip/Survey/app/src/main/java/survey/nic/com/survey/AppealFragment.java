package survey.nic.com.survey;


import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;

import survey.nic.adapter.CirclePageIndicator;
import survey.nic.adapter.CustomPagerAdapter;
import survey.nic.adapter.ReaderViewPagerTransformer;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AppealFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AppealFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    CustomPagerAdapter mCustomPagerAdapter;
    private Handler handler = new Handler();
    ViewPager mViewPager;
    int position = 0;
    // the images to display
    int[] imageIDs = { R.drawable.logo, R.drawable.logo, R.drawable.logo,
            R.drawable.logo };

    private String appealString="The nation is standing at crossroads leading to three paths. \"While one road leads to UPA government which has a record of five years of criminal neglect of development and security, the second leads to those parties whose priority is to somehow stitch up an alliance to come to power. The third road leads to BJP-led NDA which can give the country political stability, development, good governance and security to which it is committed, as it has already been proved during the six years of NDA rule.\"\n" +
            " In all these years, my dream and that of my colleagues was to make India a strong, prosperous nation... There were many who joined me on the way but the closest and most talented comrade through my journey was Advaniji... Having working together, I have been in awe of his wisdom, clarity of thought and his skill to carry people along... He has played a great role in taking BJP to its present heights... His unblemished character and firm commitment and personality...is what the nation needs today.";

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AppealFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AppealFragment newInstance(String param1, String param2) {
        AppealFragment fragment = new AppealFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public AppealFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_appeal, container, false);
        WebView webView=(WebView)rootView.findViewById(R.id.webview);;
        final ActionBar abar = ((MainActivity) getActivity()).getSupportActionBar();
        View viewActionBar = getActivity().getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        webView.loadUrl("file:///android_asset/home.html");
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("Home");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        TextView content=(TextView)rootView.findViewById(R.id.contentTv);
        content.setText(appealString);

        CirclePageIndicator indicator = (CirclePageIndicator) rootView.findViewById(R.id.indicat);
        mCustomPagerAdapter = new CustomPagerAdapter(getActivity());
        mViewPager = (ViewPager) rootView.findViewById(R.id.pager);
        mViewPager.setAdapter(mCustomPagerAdapter);
        mViewPager.setPageTransformer(false, new ReaderViewPagerTransformer(ReaderViewPagerTransformer.TransformType.DEPTH));
        indicator.setViewPager(mViewPager);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(runnable, 3000);
    }

    Runnable runnable = new Runnable() {
        public void run() {
            if (position == 4) {
                position = 0;
            }
            mViewPager.setCurrentItem(position++, true);
            handler.postDelayed(runnable, 3000);
        }
    };

}
