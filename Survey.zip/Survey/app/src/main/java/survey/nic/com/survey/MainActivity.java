package survey.nic.com.survey;

import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import survey.nic.utility.CircleTransform;
import survey.nic.utility.Util;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Fragment newFragment;
    FragmentTransaction transaction;
    private ImageView profileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        transaction = getFragmentManager().beginTransaction();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar abar = getSupportActionBar();
        View viewActionBar = getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("Home");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setSelected(true);
        Menu menu = navigationView.getMenu();
        // find MenuItem you want to change
        MenuItem nav_logout = menu.findItem(R.id.nav_logout);
        // set new title to the MenuItem
        if (Util.getUid(MainActivity.this) != null && !Util.getUid(MainActivity.this).equalsIgnoreCase("")) {
            nav_logout.setTitle("Logout");
        } else {
            nav_logout.setTitle("Login");
        }
        View header = navigationView.getHeaderView(0);
        TextView userName = (TextView) header.findViewById(R.id.userNameTv);
        TextView email = (TextView) header.findViewById(R.id.emailTv);
        profileImage = (ImageView) header.findViewById(R.id.imageView);
        String imagePath = Util.getProfileImage(MainActivity.this);
        if (imagePath != null && !imagePath.equalsIgnoreCase("")) {
            Picasso.with(MainActivity.this).load(Util.getProfileImage(MainActivity.this)).transform(new CircleTransform()).resize(300, 250).into(profileImage);
            userName.setText(Util.getUserName(MainActivity.this));//Constants.userName
        } else {
            userName.setText("");
        }

        email.setText("");//
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Util.getUid(MainActivity.this) != null && !Util.getUid(MainActivity.this).equalsIgnoreCase("")) {
                    DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    newFragment = new UpdateUserProfileFragment();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
                } else {
                    changePassword("Please login for update profile!", "Login");
                }

            }
        });
        newFragment = new AppealFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            newFragment = new AppealFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
        } else if (id == R.id.nav_about) {
            newFragment = new AboutFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();

        } else if (id == R.id.nav_users) {
            newFragment = new UserListFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();

        } else if (id == R.id.nav_events) {
            newFragment = new EventsFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
        } else if (id == R.id.nav_contact) {
            newFragment = new ContactFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
        } else if (id == R.id.nav_pasword) {
            if (Util.getUid(MainActivity.this) != null && !Util.getUid(MainActivity.this).equalsIgnoreCase("")) {
                newFragment = new ChangePasswordFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
            } else {
                changePassword("Please login for change password!", "Login");
            }
        }else if (id == R.id.nav_feedback) {
            newFragment = new FeedBackFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
        }
        else if (id == R.id.nav_logout) {
            if (Util.getUid(MainActivity.this) != null && !Util.getUid(MainActivity.this).equalsIgnoreCase("")) {
                logout();
            } else {
                changePassword("Do you want to login!", "Yes");
            }

        }else if (id == R.id.nav_profileupdate) {
            if (Util.getUid(MainActivity.this) != null && !Util.getUid(MainActivity.this).equalsIgnoreCase("")) {
                newFragment = new UpdateUserProfileFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, newFragment).commit();
            } else {
                changePassword("Please login for update profile!", "Login");
            }

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void logout() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure!");

        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                Util.clearUserDetails(MainActivity.this);
                finish();
            }
        });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }

    private void changePassword(String messge, String buttonTxt) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage(messge);

        alertDialogBuilder.setPositiveButton(buttonTxt, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                finish();
            }
        });

        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }
}
