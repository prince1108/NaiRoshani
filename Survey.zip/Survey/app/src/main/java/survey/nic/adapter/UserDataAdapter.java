package survey.nic.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import survey.nic.com.survey.R;
import survey.nic.com.survey.ViewDetailsActivity;
import survey.nic.parser.UserMetadata;
import survey.nic.utility.Util;

/**
 * Created by Ravi on 9/4/2016.
 */
public class UserDataAdapter extends BaseAdapter {
    private Context mcontext;
    private static LayoutInflater inflater = null;
    List<UserMetadata> dataList;

    public UserDataAdapter(Context context, List<UserMetadata> userData) {
        this.mcontext = context;
        this.dataList = userData;
        inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        View rowView;
        rowView = inflater.inflate(R.layout.userdata_item, null);
        TextView viewButton = (TextView) rowView.findViewById(R.id.viewButton);
        TextView userName = (TextView) rowView.findViewById(R.id.nameItemTxt);
        userName.setText(dataList.get(position).getUserName());
        TextView fatherName = (TextView) rowView.findViewById(R.id.fatherNameItemTxt);
        fatherName.setText(dataList.get(position).getFatherName());
        TextView occupation = (TextView) rowView.findViewById(R.id.occupationItemTxt);
        occupation.setText(dataList.get(position).getOcuupation());
        TextView state = (TextView) rowView.findViewById(R.id.stateItemTxt);
        state.setText(dataList.get(position).getState());
        TextView district = (TextView) rowView.findViewById(R.id.districtItemTxt);
        district.setText(dataList.get(position).getDistrict());
        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (Util.userDataList!=null&&Util.userDataList.size() > 0) {
//                    Util.userDataList.clear();
//                    Util.userDataList=null;
//                }
                Util.userDataList = dataList;
                Intent intent=new Intent(mcontext, ViewDetailsActivity.class);
                intent.putExtra("POS", position);
                mcontext.startActivity(intent);
            }
        });
        return rowView;
    }


}
