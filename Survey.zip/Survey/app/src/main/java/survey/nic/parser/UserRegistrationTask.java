package survey.nic.parser;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

import survey.nic.com.survey.Constants;
import survey.nic.utility.Util;

/**
 * Created by shankar_r on 8/29/2016.
 */
public class UserRegistrationTask extends AsyncTask<String, Void, String> {
    private Context mContext;
    private String dataString = "";
    ProgressDialog progressDialog;
    public UserRegistrationTask(Context context,String data) {
        this.mContext = context;
        this.dataString=data;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = ProgressDialog.show(mContext, "", "Please wait...", true, false);
    }

    @Override
    protected String doInBackground(String... params) {
        String response = "";
        String result="";
        BufferedReader reader = null;
        String KEY_PARENT_NODE = "row";
        String KEY_ITEM_NAME = "Result";
        System.out.println("Request===="+dataString);
        try {
            // Defined URL  where to send data
            URL url = new URL(Constants.registrationServiceURL);
            // Send POST data request
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(dataString);
            wr.flush();
            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
            }
            response = sb.toString();
            System.out.println("Response===="+response);
            XMLParser xmlParser=new XMLParser();
            Document doc = xmlParser.getDomElement(response); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                Element e = (Element) nl.item(i);
                result = xmlParser.getValue(e, KEY_ITEM_NAME);
            }
        } catch (Exception ex) {

        } finally {
            try {
                reader.close();
            } catch (Exception ex) {
            }
        }
        // Show response on activity
        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        progressDialog.dismiss();
        if(s.isEmpty()||s.equalsIgnoreCase("1")||s.equalsIgnoreCase("2")){
            Util.alertMessage(mContext, "Server is busy please try later!");
        }else if(s.equalsIgnoreCase("3")){
            Util.alertMessage(mContext, "This user hasbeen exist!");
        }else if(s.equalsIgnoreCase("success")){
            Util.alertMessage(mContext, "User Registered Successfully!");
        }else if(s.equalsIgnoreCase("update")){
            Util.alertMessage(mContext, "Data updated Successfully!");
        }
        else{
            Util.alertMessage(mContext, "Server is busy please try later!");
        }
    }
}

