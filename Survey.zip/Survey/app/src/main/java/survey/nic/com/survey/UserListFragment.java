package survey.nic.com.survey;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import survey.nic.adapter.SpinnerAdapter;
import survey.nic.parser.CommonService;
import survey.nic.parser.UserMetadata;
import survey.nic.parser.XMLParser;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UserListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class UserListFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private List<CommonService> stateList = new ArrayList<CommonService>();
    private List<CommonService> commonServiceList = new ArrayList<CommonService>();
    private List<CommonService> districtList = new ArrayList<CommonService>();
    ProgressDialog progressDialog;
    protected Spinner stateValue,districtValue,occupationValue;
    protected EditText searchValue;
    private String stateUID,districtUID,occupationStr;
    // TODO: Rename and change types and number of parameters
    public static UserListFragment newInstance(String param1, String param2) {
        UserListFragment fragment = new UserListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public UserListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_user_list, container, false);
        final Button searchBtn=(Button)rootView.findViewById(R.id.searchBtn);
        final ActionBar abar = ((MainActivity) getActivity()).getSupportActionBar();
        View viewActionBar = getActivity().getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("Search Users");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);

        stateValue=(Spinner) rootView.findViewById(R.id.stateValue);
        districtValue=(Spinner) rootView.findViewById(R.id.districtValue);
        occupationValue=(Spinner) rootView.findViewById(R.id.occupationValue);
        searchValue=(EditText) rootView.findViewById(R.id.searchValue);
        //Dynamic spinner data
        new CommonServiceExecuter("Occupation", "-1", occupationValue).execute();
        new StateServiceExecuter("state", "-1", stateValue).execute();
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String search=searchValue.getText().toString();
                Intent intent = new Intent(getActivity(), UserListActivity.class);
                intent.putExtra("STATE", stateUID);
                intent.putExtra("DISTRICT", districtUID);
                intent.putExtra("OCCUPATION",occupationStr);
                if(search.equalsIgnoreCase("")){
                    search="-1";
                }
                intent.putExtra("SEARCHVALUE",search);
                startActivity(intent);
            }
        });
        stateValue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (stateList != null && stateList.size() > 0) {
                    stateUID = stateList.get(position).get_ID();
                    new DistrictServiceExecuter("district", stateUID, districtValue).execute();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        districtValue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (districtList != null && districtList.size() > 0) {
                    districtUID = districtList.get(position).get_ID();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        occupationValue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                occupationStr = commonServiceList.get(position).get_ID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return rootView;
    }




    private class CommonServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public CommonServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            commonServiceList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

    private class StateServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public StateServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            stateList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

    private class DistrictServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public DistrictServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "District", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            districtList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            if (progressDialog != null && progressDialog.isShowing())
                progressDialog.dismiss();
            progressDialog = null;
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

}
