package survey.nic.parser;

/**
 * Created by Ravi on 8/28/2016.
 */
public class CommonService {
    public String get_ID() {
        return _ID;
    }

    public void set_ID(String _ID) {
        this._ID = _ID;
    }

    public String get_Name() {
        return _Name;
    }

    public void set_Name(String _Name) {
        this._Name = _Name;
    }

    private String _ID;
    private String _Name;
}
