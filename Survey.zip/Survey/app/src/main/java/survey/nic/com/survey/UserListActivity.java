package survey.nic.com.survey;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import survey.nic.adapter.ExpandableListAdapter;
import survey.nic.adapter.UserDataAdapter;
import survey.nic.adapter.UserListAdapter;
import survey.nic.parser.UserMetadata;
import survey.nic.parser.XMLParser;
import survey.nic.utility.Util;

public class UserListActivity extends AppCompatActivity {
    //    ExpandableListView expandableListView;
    ListView expandableListView;
    //  ExpandableListAdapter expandableListAdapter;
    UserDataAdapter userListAdapter;
    List<String> expandableListTitle;
    HashMap<String, List<UserMetadata>> expandableListDetail;
    private String SearchValue = "-1", State = "-1", District = "-1", occup = "-1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActionBar abar = getSupportActionBar();
        View viewActionBar = getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("User List");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        setContentView(R.layout.activity_user_list);
        expandableListView = (ListView) findViewById(R.id.expandableListView);
//        expandableListDetail = ExpandableListDataPump.getData();
//        expandableListTitle = new ArrayList<String>(expandableListDetail.keySet());
//        expandableListAdapter = new ExpandableListAdapter(this, expandableListTitle, expandableListDetail);
//        expandableListView.setAdapter(expandableListAdapter);

//        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
//
//            @Override
//            public void onGroupExpand(int groupPosition) {
//            }
//        });
//
//        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
//
//            @Override
//            public void onGroupCollapse(int groupPosition) {
//            }
//        });
//
//        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
//            @Override
//            public boolean onChildClick(ExpandableListView parent, View v,
//                                        int groupPosition, int childPosition, long id) {
////                Toast.makeText(
////                        getApplicationContext(),
////                        expandableListTitle.get(groupPosition)
////                                + " -> "
////                                + expandableListDetail.get(
////                                expandableListTitle.get(groupPosition)).get(
////                                childPosition), Toast.LENGTH_SHORT
////                )
////                        .show();
//                return false;
//            }
//        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Util.userDataList != null && Util.userDataList.size() > 0) {
            userListAdapter = new UserDataAdapter(UserListActivity.this, Util.userDataList);
            expandableListView.setAdapter(userListAdapter);
        } else {
            Intent intent = getIntent();
            SearchValue = intent.getStringExtra("SEARCHVALUE");
            State = intent.getStringExtra("STATE");
            District = intent.getStringExtra("DISTRICT");
            occup = intent.getStringExtra("OCCUPATION");
            new UserListTask("type=1&SearchValue=" + SearchValue + "&State=" + State + "&District=" + District + "&occup=" + occup).execute();
//            Util.alertMessage(UserListActivity.this, "Record not found!");
        }
    }

    public class UserListTask extends AsyncTask<String, Void, List<UserMetadata>> {
        private String dataString = "";
        ProgressDialog progressDialog;

        public UserListTask(String data) {
            this.dataString = data;
            expandableListDetail = new HashMap<String, List<UserMetadata>>();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(UserListActivity.this, "Search User's", "Please wait...", true, false);
        }

        @Override
        protected List<UserMetadata> doInBackground(String... params) {
            String response = "";
            List<UserMetadata> userMetadataList = new ArrayList<UserMetadata>();
            BufferedReader reader = null;
            String KEY_PARENT_NODE = "row";
            System.out.println("Request====" + dataString);
            try {
                // Defined URL  where to send data
                URL url = new URL(Constants.searchUserServiceURL);
                // Send POST data request
                URLConnection conn = url.openConnection();
                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(dataString);
                wr.flush();
                // Get the server response
                reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = null;
                // Read Server Response
                while ((line = reader.readLine()) != null) {
                    // Append server response in string
                    sb.append(line + "\n");
                }
                response = sb.toString();
//                System.out.println("Response====" + response);
                XMLParser xmlParser = new XMLParser();
                Document doc = xmlParser.getDomElement(response); // getting DOM element
                NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
                for (int i = 0; i < nl.getLength(); i++) {
                    UserMetadata userMetadata = new UserMetadata();
                    Element e = (Element) nl.item(i);
                    userMetadata.setSerialNo(i + 1 + "");
                    String reg_no = xmlParser.getValue(e, "Reg_no");
                    userMetadata.setReg_no(reg_no);
                    String user_name = xmlParser.getValue(e, "User_Name");
                    userMetadata.setUserName(user_name);
                    String father_name = xmlParser.getValue(e, "Father_Name");
                    userMetadata.setFatherName(father_name);
                    String mother_name = xmlParser.getValue(e, "Mother_Name");
                    userMetadata.setMotherName(mother_name);
                    String gender = xmlParser.getValue(e, "Gender");
                    userMetadata.setGender(gender);
                    String dob = xmlParser.getValue(e, "Dob");
                    userMetadata.setDob(dob);
                    String marital_status = xmlParser.getValue(e, "Marital_status");
                    userMetadata.setMaritalStatus(marital_status);
                    String blood_group = xmlParser.getValue(e, "Blood_group");
                    userMetadata.setBloodGroup(blood_group);
                    String gotra = xmlParser.getValue(e, "Gotra");
                    userMetadata.setGotraName(gotra);
                    String occupation = xmlParser.getValue(e, "Occupation");
                    userMetadata.setOcuupation(occupation);
                    String detailsofoccupation = xmlParser.getValue(e, "Detailsofoccupation");
                    userMetadata.setDetailsOfOccupation(detailsofoccupation);
                    String presentaddress = xmlParser.getValue(e, "Presentaddress");
                    userMetadata.setPresentAddress(presentaddress);
                    String state = xmlParser.getValue(e, "State");
                    userMetadata.setState(state);
                    String district = xmlParser.getValue(e, "District");
                    userMetadata.setDistrict(district);
                    String pincode = xmlParser.getValue(e, "Pincode");
                    userMetadata.setPinCode(pincode);

                    String email = xmlParser.getValue(e, "Email");
                    userMetadata.setEmail(email);
                    String telephone_no = xmlParser.getValue(e, "Telephone_no");
                    userMetadata.setLandLine(telephone_no);
                    String mobile = xmlParser.getValue(e, "Mobile");
                    userMetadata.setMobileNo(mobile);
                    String postgraduate = xmlParser.getValue(e, "Postgraduate");
                    userMetadata.setPostGraduation(postgraduate);
                    String graduation = xmlParser.getValue(e, "Graduation");
                    userMetadata.setGraduation(graduation);
                    String highschool = xmlParser.getValue(e, "Highschool");
                    userMetadata.setHighschool(highschool);
                    String otherd = xmlParser.getValue(e, "Otherd");
                    userMetadata.setOtherQualification(otherd);
                    String below10 = xmlParser.getValue(e, "Below10");
                    userMetadata.setBelow10TH(below10);
                    String inter = xmlParser.getValue(e, "Inter");
                    userMetadata.setInter(inter);
                    String createddate = xmlParser.getValue(e, "Createddate");
                    userMetadata.setCreatedDate(createddate);
//                    String ipaddress = xmlParser.getValue(e, "Ipaddress");
//                    String status = xmlParser.getValue(e, "Status");
                    String designation = xmlParser.getValue(e, "Designation");
                    userMetadata.setDesignation(designation);
                    String permaentAddress = xmlParser.getValue(e, "Permenentaddress");
                    userMetadata.setPermanentAddress(permaentAddress);
                    String hobbies = xmlParser.getValue(e, "Hobbies");
                    userMetadata.setHobbies(hobbies);
                    String AlterNO = xmlParser.getValue(e, "Altno");
                    userMetadata.setAlternateNo(AlterNO);
                    String maternalGotra = xmlParser.getValue(e, "Mgotra");
                    userMetadata.setMaternalGotraName(maternalGotra);
                    String profileImage = xmlParser.getValue(e, "Profile_Image");
                    userMetadata.setProfile_Image(profileImage);
                    String spouseName = xmlParser.getValue(e, "Spouse_name");
                    userMetadata.setSpouseName(spouseName);
                    String haveChild = xmlParser.getValue(e, "hychild");
                    userMetadata.setmHaveChild(haveChild);
                    String child1 = xmlParser.getValue(e, "chil1");
                    userMetadata.setChild1Name(child1);
                    String child2 = xmlParser.getValue(e, "child2");
                    userMetadata.setChild2Name(child2);
                    String child3 = xmlParser.getValue(e, "child3");
                    userMetadata.setChild3Name(child3);
                    String child4 = xmlParser.getValue(e, "child4");
                    userMetadata.setChild4Name(child4);
                    userMetadataList.add(userMetadata);
                    expandableListDetail.put(i + "", userMetadataList);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    reader.close();
                } catch (Exception ex) {
                }
            }
            // Show response on activity
            return userMetadataList;
        }

        @Override
        protected void onPostExecute(List<UserMetadata> result) {
            super.onPostExecute(result);
            progressDialog.dismiss();
//            expandableListTitle = new ArrayList<String>(expandableListDetail.keySet());
            if (result != null && result.size() > 0) {
                userListAdapter = new UserDataAdapter(UserListActivity.this, result);
                expandableListView.setAdapter(userListAdapter);
//                expandableListAdapter = new ExpandableListAdapter(UserListActivity.this,expandableListTitle,expandableListDetail);
//                expandableListView.setAdapter(expandableListAdapter);
            } else {
                Util.alertMessage(UserListActivity.this, "Record not found!");
            }

        }
    }

}
