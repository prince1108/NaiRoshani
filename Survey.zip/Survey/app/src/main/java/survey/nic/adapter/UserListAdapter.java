package survey.nic.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import survey.nic.com.survey.R;
import survey.nic.parser.CommonService;
import survey.nic.parser.UserMetadata;

/**
 * Created by Ravi on 9/4/2016.
 */
public class UserListAdapter extends BaseAdapter {
    private Context mcontext;
    private static LayoutInflater inflater = null;
    List<UserMetadata> dataList;

    public UserListAdapter(Context context, List<UserMetadata> userData) {
        this.mcontext = context;
        this.dataList = userData;
        inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        View rowView;
        rowView = inflater.inflate(R.layout.list_item, null);
        final LinearLayout linearLayout = (LinearLayout) rowView.findViewById(R.id.layoutExpand);
        TextView itemName = (TextView) rowView.findViewById(R.id.listTitle);
        itemName.setText("Serial No " + dataList.get(position).getSerialNo());
        TextView userName = (TextView) rowView.findViewById(R.id.nameItemTxt);
        userName.setText(dataList.get(position).getUserName());
        TextView fatherName = (TextView) rowView.findViewById(R.id.fatherNameItemTxt);
        fatherName.setText(dataList.get(position).getFatherName());
        TextView motherName = (TextView) rowView.findViewById(R.id.motherNameItemTxt);
        motherName.setText(dataList.get(position).getMotherName());
        TextView spouseName = (TextView) rowView.findViewById(R.id.spouseNameItemTxt);
        spouseName.setText(dataList.get(position).getSpouseName());
        TextView dob = (TextView) rowView.findViewById(R.id.dobItemTxt);
        dob.setText(dataList.get(position).getDob());
        TextView maritalStatus = (TextView) rowView.findViewById(R.id.maritalStatusItemTxt);
        maritalStatus.setText(dataList.get(position).getMaritalStatus());
        TextView bloodGroup = (TextView) rowView.findViewById(R.id.bloodGroupItemTxt);
        bloodGroup.setText(dataList.get(position).getBloodGroup());
        TextView gotra = (TextView) rowView.findViewById(R.id.gotraItemTxt);
        gotra.setText(dataList.get(position).getGotraName());
        TextView maternalGotra = (TextView) rowView.findViewById(R.id.maternalGotraItemTxt);
        maternalGotra.setText(dataList.get(position).getMaternalGotraName());
        TextView childrenTxt = (TextView) rowView.findViewById(R.id.childrenItemTxt);
        childrenTxt.setText(dataList.get(position).getChild1Name()+","+dataList.get(position).getChild2Name()+","+dataList.get(position).getChild3Name()+","+dataList.get(position).getChild4Name());
        TextView occupation = (TextView) rowView.findViewById(R.id.occupationItemTxt);
        occupation.setText(dataList.get(position).getOcuupation());
        TextView department = (TextView) rowView.findViewById(R.id.DeptandDesigItemTxt);
        department.setText(dataList.get(position).getDesignation());
        TextView presentAddress = (TextView) rowView.findViewById(R.id.presentItemTxt);
        presentAddress.setText(dataList.get(position).getPresentAddress());
        TextView permanentAddress = (TextView) rowView.findViewById(R.id.permanentItemTxt);
        permanentAddress.setText(dataList.get(position).getPermanentAddress());
        TextView hobbies = (TextView) rowView.findViewById(R.id.hobbiesItemTxt);
        hobbies.setText(dataList.get(position).getHobbies());
        TextView state = (TextView) rowView.findViewById(R.id.stateItemTxt);
        state.setText(dataList.get(position).getState());
        TextView district = (TextView) rowView.findViewById(R.id.districtItemTxt);
        district.setText(dataList.get(position).getDistrict());
        TextView pinCode = (TextView) rowView.findViewById(R.id.pincodeItemTxt);
        pinCode.setText(dataList.get(position).getPinCode());
        TextView postGraduation = (TextView) rowView.findViewById(R.id.postGradItemTxt);
        postGraduation.setText(dataList.get(position).getPostGraduation());
        TextView graduation = (TextView) rowView.findViewById(R.id.graduationItemTxt);
        graduation.setText(dataList.get(position).getGraduation());
        TextView class12plus = (TextView) rowView.findViewById(R.id.class10th2ItemTxt);
        class12plus.setText(dataList.get(position).getInter());
        TextView class10th = (TextView) rowView.findViewById(R.id.class10thItemTxt);
        class10th.setText(dataList.get(position).getHighschool());

        itemName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dataList.get(position).getIsClicked()) {
                    linearLayout.setVisibility(View.VISIBLE);
                    dataList.get(position).setIsClicked(false);
                } else {
                    dataList.get(position).setIsClicked(true);
                    linearLayout.setVisibility(View.GONE);
                }
            }
        });
        return rowView;
    }


}
