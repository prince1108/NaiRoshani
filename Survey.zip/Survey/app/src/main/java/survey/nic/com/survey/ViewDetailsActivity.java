package survey.nic.com.survey;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import survey.nic.utility.Util;

public class ViewDetailsActivity extends AppCompatActivity {

    private int position=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActionBar abar = getSupportActionBar();
        View viewActionBar = getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("User Detail");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);

        setContentView(R.layout.activity_view_details);
        Intent intent=getIntent();
        position=intent.getIntExtra("POS",0);
        if(Util.userDataList!=null&&Util.userDataList.size()>0){
            initViews();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    private void initViews(){
        LinearLayout emailLayout = (LinearLayout) findViewById(R.id.emailLayout);
        LinearLayout mobileLayout = (LinearLayout) findViewById(R.id.mobileLayout);
        LinearLayout alternateLayout = (LinearLayout) findViewById(R.id.alternateLayout);
        TextView emailName = (TextView) findViewById(R.id.emailaddressTxt);
        emailName.setText(Util.userDataList.get(position).getEmail());
        TextView mobile = (TextView) findViewById(R.id.mobileTxt);
        mobile.setText(Util.userDataList.get(position).getMobileNo());
        TextView alternateNO = (TextView) findViewById(R.id.alternateMobileTxt);
        alternateNO.setText(Util.userDataList.get(position).getAlternateNo());

        if (Util.getUid(ViewDetailsActivity.this)!=null&&!Util.getUid(ViewDetailsActivity.this).equalsIgnoreCase("")){
            emailLayout.setVisibility(View.VISIBLE);
            mobileLayout.setVisibility(View.VISIBLE);
            alternateLayout.setVisibility(View.VISIBLE);

        }else{
            emailLayout.setVisibility(View.GONE);
            mobileLayout.setVisibility(View.GONE);
            alternateLayout.setVisibility(View.GONE);
        }
        TextView userName = (TextView) findViewById(R.id.nameItemTxt);
        userName.setText(Util.userDataList.get(position).getUserName());
        TextView fatherName = (TextView) findViewById(R.id.fatherNameItemTxt);
        fatherName.setText(Util.userDataList.get(position).getFatherName());
        TextView motherName = (TextView) findViewById(R.id.motherNameItemTxt);
        motherName.setText(Util.userDataList.get(position).getMotherName());
        TextView spouseName = (TextView) findViewById(R.id.spouseNameItemTxt);
        spouseName.setText(Util.userDataList.get(position).getSpouseName());
        TextView dob = (TextView) findViewById(R.id.dobItemTxt);
        dob.setText(Util.userDataList.get(position).getDob());
        TextView maritalStatus = (TextView) findViewById(R.id.maritalStatusItemTxt);
        maritalStatus.setText(Util.userDataList.get(position).getMaritalStatus());
        TextView bloodGroup = (TextView) findViewById(R.id.bloodGroupItemTxt);
        bloodGroup.setText(Util.userDataList.get(position).getBloodGroup());
        TextView gotra = (TextView) findViewById(R.id.gotraItemTxt);
        gotra.setText(Util.userDataList.get(position).getGotraName());
        TextView maternalGotra = (TextView) findViewById(R.id.maternalGotraItemTxt);
        maternalGotra.setText(Util.userDataList.get(position).getMaternalGotraName());
        TextView childrenTxt = (TextView) findViewById(R.id.childrenItemTxt);
        childrenTxt.setText(Util.userDataList.get(position).getChild1Name()+","+Util.userDataList.get(position).getChild2Name()+","+Util.userDataList.get(position).getChild3Name()+","+Util.userDataList.get(position).getChild4Name());
        TextView occupation = (TextView) findViewById(R.id.occupationItemTxt);
        occupation.setText(Util.userDataList.get(position).getOcuupation());
        TextView department = (TextView) findViewById(R.id.DeptandDesigItemTxt);
        department.setText(Util.userDataList.get(position).getDesignation());
        TextView presentAddress = (TextView) findViewById(R.id.presentItemTxt);
        presentAddress.setText(Util.userDataList.get(position).getPresentAddress());
        TextView permanentAddress = (TextView) findViewById(R.id.permanentItemTxt);
        permanentAddress.setText(Util.userDataList.get(position).getPermanentAddress());
        TextView hobbies = (TextView) findViewById(R.id.hobbiesItemTxt);
        hobbies.setText(Util.userDataList.get(position).getHobbies());
        TextView state = (TextView) findViewById(R.id.stateItemTxt);
        state.setText(Util.userDataList.get(position).getState());
        TextView district = (TextView) findViewById(R.id.districtItemTxt);
        district.setText(Util.userDataList.get(position).getDistrict());
        TextView pinCode = (TextView) findViewById(R.id.pincodeItemTxt);
        pinCode.setText(Util.userDataList.get(position).getPinCode());
        TextView postGraduation = (TextView) findViewById(R.id.postGradItemTxt);
        postGraduation.setText(Util.userDataList.get(position).getPostGraduation());
        TextView graduation = (TextView) findViewById(R.id.graduationItemTxt);
        graduation.setText(Util.userDataList.get(position).getGraduation());
        TextView class12plus = (TextView) findViewById(R.id.class10th2ItemTxt);
        class12plus.setText(Util.userDataList.get(position).getInter());
        TextView class10th = (TextView) findViewById(R.id.class10thItemTxt);
        class10th.setText(Util.userDataList.get(position).getHighschool());
    }
}
