package survey.nic.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import survey.nic.com.survey.R;
import survey.nic.parser.EventMetaData;


/**
 * Created by Ravi on 8/25/2016.
 */
public class EventDetailPagerAdapter extends PagerAdapter {
    Context mContext;
    LayoutInflater mLayoutInflater;
    List<EventMetaData> mListData;
    String[] imageIDs = {"http://www.nairoshani.com/images/mobimg1.png","http://www.nairoshani.com/images/mobimg2.png",
            "http://www.nairoshani.com/images/mobimg3.png","http://www.nairoshani.com/images/mobimg4.png" };
    public EventDetailPagerAdapter(Context context,List<EventMetaData> listData) {
        mContext = context;
        this.mListData=listData;
        mLayoutInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mListData.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = mLayoutInflater.inflate(R.layout.event_pager_item,
                container, false);
        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);
        TextView contentTv= (TextView) itemView.findViewById(R.id.contentTv);
//        imageView.setImageResource(imageIDs[position]);
        contentTv.setText(mListData.get(position).getEventtext());
        Picasso.with(mContext).load(mListData.get(position).getImage()).resize(300,250).into(imageView);
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}
