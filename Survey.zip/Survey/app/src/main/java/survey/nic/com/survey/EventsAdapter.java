package survey.nic.com.survey;

/**
 * Created by shankar_r on 6/14/2016.
 */

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import survey.nic.parser.EventMetaData;
import survey.nic.utility.CircleTransform;
import survey.nic.utility.Util;


public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.ViewHolder> {
    private Context context;
    List<EventMetaData> mListData;
    public EventsAdapter(Context context,List<EventMetaData> listData) {
        this.context = context;
        this.mListData=listData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.events_item_row, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        viewHolder.eventtxt.setText(mListData.get(i).getEventtext());
        viewHolder.tv_date.setText("Event on "+mListData.get(i).getEventDate());
        Picasso.with(context).load(mListData.get(i).getImage()).resize(300, 250).into(viewHolder.eventImage);
        viewHolder.eventImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EventDetailActivity.class);
                intent.putExtra("EventID", mListData.get(i).getEventDate());
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView eventtxt,tv_date;
        private ImageView eventImage;

        public ViewHolder(View view) {
            super(view);
            eventImage = (ImageView) view.findViewById(R.id.eventImage);
            eventtxt = (TextView) view.findViewById(R.id.event_text);
            tv_date = (TextView) view.findViewById(R.id.tv_date);
        }
    }


}