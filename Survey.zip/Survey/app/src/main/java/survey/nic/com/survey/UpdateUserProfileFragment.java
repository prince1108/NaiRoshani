package survey.nic.com.survey;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import survey.nic.adapter.SpinnerAdapter;
import survey.nic.parser.CheckConnection;
import survey.nic.parser.CommonService;
import survey.nic.parser.UserMetadata;
import survey.nic.parser.UserRegistrationTask;
import survey.nic.parser.XMLParser;
import survey.nic.utility.Util;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UpdateUserProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class UpdateUserProfileFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String genderStr = "", monthStr = "", dayStr = "", yearStr = "", maritalStr = "", haveuChildStr = "", detailofOccupationStr = "", hobbiesStr = "-1", stateStr = "", districtStr = "";
    protected Spinner mFatherSpinner, mMotherSpinner, mGenderSpinner, mBloodSpinner;
    protected Spinner mMonthSpinner, mDaySpinner, mYearSpinner, mMaritalSpinner;
    protected Spinner mChildrenSpinner, mOccupationSpinner;
    protected Spinner mStateSpinner, mDistrictSpinner, mGraduationSpinner1;
    protected Spinner mBelow10thSpinner, m10thSpinner, m12thSpinner1, m12thSpinner2;
    protected Spinner mPostGraduationSpinner1, mPostGraduationSpinner2, mGraduationSpinner2;
    MultiSpinner multiSpinner;
    protected EditText mUserNameTxt, alternatemobileSTDTxt, mFatherNameTxt, mMotherNameTxt, mSpouseNameTxt, mGotraNameTxt, mMobileSTDTxt;
    protected EditText mMaternalGotraTxt, mChildren1Txt, mChildren2Txt, mChildren3Txt, mChildren4Txt;
    protected EditText mDepartmentTxt, mOccupationTxt, mPresentAddressTxt, mPermanentAddressTxt, landlineSTDTxt;
    protected EditText mPinCodeTxt, mEmailTxt, mLandLineTxt, mMobileTxt, mAlternatenoTxt, mOtherQualificationTxt;
    TextView depatrtmentandDesignationTextView;
    protected Button mSubmitBtn;
    protected CheckBox checkBox;
    LinearLayout linearLayout;
    private List<CommonService> stateList = new ArrayList<CommonService>();
    private List<CommonService> commonServiceList = new ArrayList<CommonService>();
    private List<CommonService> districtList = new ArrayList<CommonService>();
    private List<CommonService> gradList = new ArrayList<CommonService>();
    private List<CommonService> postGradList = new ArrayList<CommonService>();
    UserMetadata userMetadata = new UserMetadata();
    UserMetadata getUserData=new UserMetadata();
    ProgressDialog progressDialog;
    // TODO: Rename and change types and number of parameters
    public static UpdateUserProfileFragment newInstance(String param1, String param2) {
        UpdateUserProfileFragment fragment = new UpdateUserProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public UpdateUserProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_update_user_profile, container, false);
        final ActionBar abar = ((MainActivity) getActivity()).getSupportActionBar();
        View viewActionBar = getActivity().getLayoutInflater().inflate(R.layout.header_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("Edit Profile");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        linearLayout=(LinearLayout)rootView.findViewById(R.id.childrenLayout);
        initSpinnerViews(rootView);
        initTextViews(rootView);
        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = mEmailTxt.getText().toString().trim();
                final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                CheckConnection checkConnection = new CheckConnection(getActivity());
                boolean isConnected = checkConnection.isNetworkAvailable(getActivity());
                String dataString = getValueFromViews();
                if (mUserNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter your name!");
                } else if (mFatherNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter father name!");
                } else if (mMotherNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter mother name!");
                } else if (genderStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please select gender!");
                } else if (monthStr.equalsIgnoreCase("") || dayStr.equalsIgnoreCase("") || yearStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please select date of birth!");
                } else if (maritalStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please select marital status!");
                } else if (haveuChildStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please select have you children!");
                } else if (haveuChildStr.equalsIgnoreCase("yes")&&mChildren1Txt.getText().toString().equalsIgnoreCase("") && mChildren2Txt.getText().toString().equalsIgnoreCase("") && mChildren3Txt.getText().toString().equalsIgnoreCase("") && mChildren4Txt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter at least one name of children!");
                } else if (detailofOccupationStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter detail of occupation!");
                } else if (mDepartmentTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter department and designation!");
                } else if (mOccupationTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please select occupation!");
                } else if (hobbiesStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "Select Hobbies");
                } else if (mPresentAddressTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter present address!");
                } else if (mPermanentAddressTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter permanent address!");
                } else if (stateStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "Select State");
                } else if (districtStr.equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "Select District");
                } else if (mMobileTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(getActivity(), "please enter mobile no!");
                } else if (!email.matches(emailPattern)) {
                    Util.alertMessage(getActivity(), "please enter valid email address!");
                }else  if (isConnected) {
                    new UserRegistrationTask(getActivity(), dataString).execute();
                } else {
                    Util.alertMessage(getActivity(), "please check internet connection!");
                }

            }
        });
        return rootView;
    }

    private String getValueFromViews() {
        userMetadata.setUserName(mUserNameTxt.getText().toString());
        userMetadata.setFatherName(mFatherNameTxt.getText().toString());
        userMetadata.setMotherName(mMotherNameTxt.getText().toString());
        userMetadata.setSpouseName(mSpouseNameTxt.getText().toString());
        userMetadata.setGotraName(mGotraNameTxt.getText().toString());
        userMetadata.setMaternalGotraName(mMaternalGotraTxt.getText().toString());
        userMetadata.setChild1Name(mChildren1Txt.getText().toString());
        userMetadata.setChild2Name(mChildren2Txt.getText().toString());
        userMetadata.setChild3Name(mChildren3Txt.getText().toString());
        userMetadata.setChild4Name(mChildren4Txt.getText().toString());
        userMetadata.setDepartment(mDepartmentTxt.getText().toString());
        userMetadata.setOcuupation(mOccupationTxt.getText().toString());
        userMetadata.setPresentAddress(mPresentAddressTxt.getText().toString());
        userMetadata.setPermanentAddress(mPermanentAddressTxt.getText().toString());
        userMetadata.setPinCode(mPinCodeTxt.getText().toString());
        userMetadata.setEmail(mEmailTxt.getText().toString());
        userMetadata.setLandLine(mLandLineTxt.getText().toString());
        userMetadata.setMobileNo(mMobileTxt.getText().toString());
        userMetadata.setAlternateNo(mAlternatenoTxt.getText().toString());
        userMetadata.setOtherQualification(mOtherQualificationTxt.getText().toString());

        StringBuilder requestBuilder = new StringBuilder();
        requestBuilder.append("uid=");
        requestBuilder.append(Util.getUid(getActivity()));
        requestBuilder.append("&type=");
        requestBuilder.append("update");
        requestBuilder.append("&UName=");
        requestBuilder.append(userMetadata.getUserName());
        requestBuilder.append("&FNameTitle=");
        requestBuilder.append(userMetadata.getFatherTitle());
        requestBuilder.append("&FName=");
        requestBuilder.append(userMetadata.getFatherName());
        requestBuilder.append("&MNameTitle=");
        requestBuilder.append(userMetadata.getMotherTitle());
        requestBuilder.append("&MName=");
        requestBuilder.append(userMetadata.getMotherName());
        requestBuilder.append("&Gender=");
        requestBuilder.append(userMetadata.getmGender());
        requestBuilder.append("&BirthMonth=");
        requestBuilder.append(userMetadata.getmMonth());
        requestBuilder.append("&BirthDay=");
        requestBuilder.append(userMetadata.getmDay());
        requestBuilder.append("&BirthYear=");
        requestBuilder.append(userMetadata.getmYear());
        requestBuilder.append("&MaritalStatus=");
        requestBuilder.append(userMetadata.getMaritalStatus());
        requestBuilder.append("&SpName=");
        requestBuilder.append(userMetadata.getSpouseName());
        requestBuilder.append("&BloodGroup=");
        requestBuilder.append(userMetadata.getBloodGroup());
        requestBuilder.append("&Gotra=");
        requestBuilder.append(userMetadata.getGotraName());
        requestBuilder.append("&MetGotra=");
        requestBuilder.append(userMetadata.getMaternalGotraName());
        requestBuilder.append("&HaveYChildren=");//new added
        requestBuilder.append("No");//new added
        requestBuilder.append("&ChildName1=");
        requestBuilder.append(userMetadata.getChild1Name());
        requestBuilder.append("&ChildName2=");
        requestBuilder.append(userMetadata.getChild2Name());
        requestBuilder.append("&ChildName3=");
        requestBuilder.append(userMetadata.getChild3Name());
        requestBuilder.append("&ChildName4=");
        requestBuilder.append(userMetadata.getChild4Name());
        requestBuilder.append("&DetailOfOccupation=");
        requestBuilder.append(userMetadata.getDetailsOfOccupation());
        requestBuilder.append("&DeptDesig=");
        requestBuilder.append(userMetadata.getDepartment());
        requestBuilder.append("&Occupation=");
        requestBuilder.append(userMetadata.getOcuupation());
        requestBuilder.append("&HobInt=");
        requestBuilder.append(userMetadata.getHobbies());
        requestBuilder.append("&PresAddress=");
        requestBuilder.append(userMetadata.getPresentAddress());
        requestBuilder.append("&SameAddress=");
        requestBuilder.append("true");//TODO
        requestBuilder.append("&PermAddress=");
        requestBuilder.append(userMetadata.getPermanentAddress());
        requestBuilder.append("&State=");
        requestBuilder.append(userMetadata.getState());
        requestBuilder.append("&District=");
        requestBuilder.append(userMetadata.getDistrict());
        requestBuilder.append("&PinCode=");
        requestBuilder.append(userMetadata.getPinCode());
        requestBuilder.append("&EmailAdd=");
        requestBuilder.append(userMetadata.getEmail());
        requestBuilder.append("&TelePhoneNo1=");
        requestBuilder.append(landlineSTDTxt.getText().toString());
        requestBuilder.append("&TelePhoneNo2=");
        requestBuilder.append(mLandLineTxt.getText().toString());
        requestBuilder.append("&Mobile1=");
        requestBuilder.append(mMobileSTDTxt.getText().toString());
        requestBuilder.append("&Mobile2=");
        requestBuilder.append(userMetadata.getMobileNo());
        requestBuilder.append("&AltMobileNo1=");
        requestBuilder.append(alternatemobileSTDTxt.getText().toString());
        requestBuilder.append("&AltMobileNo2=");
        requestBuilder.append(userMetadata.getAlternateNo());
        requestBuilder.append("&below10th=");
        requestBuilder.append(userMetadata.getBelow10TH());
        requestBuilder.append("&Class10th=");
        requestBuilder.append(userMetadata.getClass10TH());
        requestBuilder.append("&Class12thboard=");
        requestBuilder.append(userMetadata.getClass12TH());
        requestBuilder.append("&Class12thType=");
        requestBuilder.append(userMetadata.getmClass12th2());
        requestBuilder.append("&GraduationCourse=");
        requestBuilder.append(userMetadata.getGraduation());
        requestBuilder.append("&GraduationType=");
        requestBuilder.append(userMetadata.getGraduationType());
        requestBuilder.append("&PGraduationCourse=");
        requestBuilder.append(userMetadata.getPostGraduation());
        requestBuilder.append("&PGraduationType=");
        requestBuilder.append(userMetadata.getPostGraduationType());
        requestBuilder.append("&OtherQualification=");
        requestBuilder.append(userMetadata.getOtherQualification());
        requestBuilder.append("&IpAddress=");
        requestBuilder.append("192.12.45.65");
        return requestBuilder.toString();

    }

    private void initTextViews(View rootViews) {
        checkBox = (CheckBox)rootViews. findViewById(R.id.checkbox);
        depatrtmentandDesignationTextView= (TextView)rootViews. findViewById(R.id.depatrtmentandDesignationTextView);
        mSubmitBtn = (Button) rootViews.findViewById(R.id.submitBtn);
        mUserNameTxt = (EditText) rootViews.findViewById(R.id.userNameTxt);
        mFatherNameTxt = (EditText)rootViews. findViewById(R.id.fatherNameTxt);
        mMotherNameTxt = (EditText) rootViews.findViewById(R.id.motherNameTxt);
        mSpouseNameTxt = (EditText)rootViews. findViewById(R.id.spouseNameTxt);
        mGotraNameTxt = (EditText)rootViews. findViewById(R.id.gotraTxt);
        mMaternalGotraTxt = (EditText)rootViews. findViewById(R.id.metrnalgotraTxt);
        mChildren1Txt = (EditText) rootViews.findViewById(R.id.children1Txt);
        mChildren2Txt = (EditText)rootViews. findViewById(R.id.children2Txt);
        mChildren3Txt = (EditText)rootViews. findViewById(R.id.children3Txt);
        mChildren4Txt = (EditText) rootViews.findViewById(R.id.children4Txt);
        mDepartmentTxt = (EditText)rootViews. findViewById(R.id.departmentTxt);
        mOccupationTxt = (EditText) rootViews.findViewById(R.id.occupationTxt);
        mPresentAddressTxt = (EditText)rootViews. findViewById(R.id.presentaddressTxt);
        mPermanentAddressTxt = (EditText) rootViews.findViewById(R.id.permanentaddressTxt);
        mPinCodeTxt = (EditText) rootViews.findViewById(R.id.pincodeTxt);
        mEmailTxt = (EditText) rootViews.findViewById(R.id.emailaddressTxt);
        landlineSTDTxt = (EditText)rootViews. findViewById(R.id.landlineSTDTxt);
        mLandLineTxt = (EditText) rootViews.findViewById(R.id.landlineTxt);
        mMobileTxt = (EditText) rootViews.findViewById(R.id.mobileTxt);
        mMobileSTDTxt = (EditText)rootViews. findViewById(R.id.mobileSTDTxt);
        mAlternatenoTxt = (EditText)rootViews. findViewById(R.id.alternatemobileTxt);
        alternatemobileSTDTxt = (EditText) rootViews.findViewById(R.id.alternatemobileSTDTxt);
        mOtherQualificationTxt = (EditText)rootViews. findViewById(R.id.otherqualificationTxt);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mPermanentAddressTxt.setText(mPresentAddressTxt.getText().toString());
                } else {
                    mPermanentAddressTxt.setText("");
                }
            }
        });
    }

    private void initSpinnerViews(View rootViews) {
        /*
        @Personnel Information Spinners
         */
        mFatherSpinner = (Spinner) rootViews.findViewById(R.id.fatherSpin);
        mMotherSpinner = (Spinner)rootViews. findViewById(R.id.motherSpin);
        mGenderSpinner = (Spinner)rootViews. findViewById(R.id.genderSpin);
        mMonthSpinner = (Spinner) rootViews.findViewById(R.id.monthSpin);
        mDaySpinner = (Spinner) rootViews.findViewById(R.id.daySpin);
        mYearSpinner = (Spinner) rootViews.findViewById(R.id.yearSpin);
        mMaritalSpinner = (Spinner) rootViews.findViewById(R.id.maritalSpin);//TODO
        mBloodSpinner = (Spinner) rootViews.findViewById(R.id.bloodSpin);
        mChildrenSpinner = (Spinner) rootViews.findViewById(R.id.childrenSpin);
        mOccupationSpinner = (Spinner) rootViews.findViewById(R.id.detailsOccupationSpin);//TODO
        multiSpinner = (MultiSpinner) rootViews.findViewById(R.id.multispinner);
        /*
        @Address Spinners
         */
        mStateSpinner = (Spinner) rootViews.findViewById(R.id.stateSpin);//TODO
        mDistrictSpinner = (Spinner)rootViews. findViewById(R.id.districtSpin);//TODO
        /*
        @Qualification Spinners
         */
        mBelow10thSpinner = (Spinner)rootViews. findViewById(R.id.below10thSpin);
        m10thSpinner = (Spinner)rootViews. findViewById(R.id.tenthclassSpin);
        m12thSpinner1 = (Spinner)rootViews. findViewById(R.id.twelthclass1Spin);
        m12thSpinner2 = (Spinner)rootViews. findViewById(R.id.twelthclass2Spin);
        mPostGraduationSpinner1 = (Spinner)rootViews. findViewById(R.id.postgrad1Spin);//TODO
        mPostGraduationSpinner2 = (Spinner)rootViews. findViewById(R.id.postgrad2Spin);
        mGraduationSpinner1 = (Spinner) rootViews.findViewById(R.id.grad1Spin);//TODO
        mGraduationSpinner2 = (Spinner)rootViews. findViewById(R.id.grad2Spin);

        //Dynamic spinner data
        new UpdateUserProfileTask().execute();
        new CommonServiceExecuter("Occupation", "-1", mOccupationSpinner).execute();
        new CommonServiceExecuter("Post", "-1", mPostGraduationSpinner1).execute();
        new CommonServiceExecuter("Grad", "-1", mGraduationSpinner1).execute();
        new CommonServiceExecuter("Marital", "-1", mMaritalSpinner).execute();
        new StateServiceExecuter("state", "-1", mStateSpinner).execute();

        setPersonnelSpinnerData();
    }

    private void setPersonnelSpinnerData() {
        ArrayAdapter mFatherAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Father));
        mFatherSpinner.setAdapter(mFatherAdapter);

        mFatherSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mFatherTitle = getResources().getStringArray(R.array.Father)[position];
                userMetadata.setFatherTitle(mFatherTitle);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter mMotherAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Mother));
        mMotherSpinner.setAdapter(mMotherAdapter);
        mMotherSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mMotherTitle = getResources().getStringArray(R.array.Mother)[position];
                userMetadata.setMotherTitle(mMotherTitle);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mGenderAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Gender));
        mGenderSpinner.setAdapter(mGenderAdapter);
        mGenderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mGender = getResources().getStringArray(R.array.Gender)[position];
                if (position != 0) {
                    genderStr = mGender;
                    userMetadata.setmGender(mGender);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mMonthAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Month));
        mMonthSpinner.setAdapter(mMonthAdapter);
        mMonthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mMonth = getResources().getStringArray(R.array.Month_Code)[position];
                if (position != 0) {
                    monthStr = mMonth;
                    userMetadata.setmMonth(mMonth);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mDayAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Day));
        mDaySpinner.setAdapter(mDayAdapter);
        mDaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mDay = getResources().getStringArray(R.array.Day)[position];
                if (position != 0) {
                    dayStr = mDay;
                    userMetadata.setmDay(mDay);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mYearAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Year));
        mYearSpinner.setAdapter(mYearAdapter);
        mYearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mYear = getResources().getStringArray(R.array.Year)[position];
                if (position != 0) {
                    yearStr = mYear;
                    userMetadata.setmYear(mYear);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mBloodGroupAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Blood_Group));
        mBloodSpinner.setAdapter(mBloodGroupAdapter);
        mBloodSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mBloodGroup = getResources().getStringArray(R.array.Blood_Group)[position];
                userMetadata.setBloodGroup(mBloodGroup);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mChildrenGroupAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Children));
        mChildrenSpinner.setAdapter(mChildrenGroupAdapter);
        mChildrenSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mHaveChild = getResources().getStringArray(R.array.Children)[position];
                if (position == 1) {
                    linearLayout.setVisibility(View.VISIBLE);
                    haveuChildStr = mHaveChild;
                    userMetadata.setmHaveChild(mHaveChild);
                } else {
                    linearLayout.setVisibility(View.GONE);
                    mChildren1Txt.setText("");
                    mChildren2Txt.setText("");
                    mChildren3Txt.setText("");
                    mChildren4Txt.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mHobbiesAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Hobbies));
        String arr[]=getResources().getStringArray(R.array.Hobbies);
        List<String> list = new ArrayList<String>();
        for(int i=1;i<arr.length;i++){
            list.add(arr[i]);
        }
        multiSpinner.setItems(list);
//        multiSpinner.setAdapter(mHobbiesAdapter);//mHobbiesSpinner
        multiSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mHobbies = getResources().getStringArray(R.array.Hobbies)[position];
                if (position != 0) {
                    hobbiesStr = mHobbies;
                    userMetadata.setHobbies(mHobbies);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        /*
        @Qualification Spinners
         */
        ArrayAdapter mBelow10thAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Below10th));
        mBelow10thSpinner.setAdapter(mBelow10thAdapter);
        mBelow10thSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mBelow10th = getResources().getStringArray(R.array.Below10th)[position];
                userMetadata.setBelow10TH(mBelow10th);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass10thAdapter = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class10th));
        m10thSpinner.setAdapter(mClass10thAdapter);
        m10thSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mClass10th = getResources().getStringArray(R.array.Class10th)[position];
                userMetadata.setClass10TH(mClass10th);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass12thAdapter1 = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class10th));
        m12thSpinner1.setAdapter(mClass12thAdapter1);
        m12thSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {//TODO
                String mClass12th1 = getResources().getStringArray(R.array.Class10th)[position];
                userMetadata.setClass12TH(mClass12th1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass12thAdapter2 = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class12th2));
        m12thSpinner2.setAdapter(mClass12thAdapter2);
        m12thSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mClass12th2 = getResources().getStringArray(R.array.Class12th2)[position];
                userMetadata.setmClass12th2(mClass12th2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mGraduationAdapter2 = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.CommonGraduation));
        mGraduationSpinner2.setAdapter(mGraduationAdapter2);
        mGraduationSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String graduationType = getResources().getStringArray(R.array.CommonGraduation)[position];
                userMetadata.setGraduationType(graduationType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mPostGraduationAdapter2 = new ArrayAdapter<String>(
                getActivity(),
                R.layout.spinner_item,
                getResources().getStringArray(R.array.CommonGraduation));
        mPostGraduationSpinner2.setAdapter(mPostGraduationAdapter2);

        mPostGraduationSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String postGraduationType = getResources().getStringArray(R.array.CommonGraduation)[position];
                userMetadata.setPostGraduationType(postGraduationType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mOccupationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String name =commonServiceList.get(position).get_Name();
                if(name.equalsIgnoreCase("Business")){
                    depatrtmentandDesignationTextView.setText("Turn Over");
                }else if(name.equalsIgnoreCase("Student")){
                    depatrtmentandDesignationTextView.setText("School Name");
                }else{
                    depatrtmentandDesignationTextView.setText("Department and Designation");
                }
                if(position>0){
                    detailofOccupationStr = commonServiceList.get(position).get_ID();
                    userMetadata.setDetailsOfOccupation(detailofOccupationStr);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mMaritalSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position!=0){
                    maritalStr = commonServiceList.get(position).get_ID();
                    userMetadata.setMaritalStatus(maritalStr);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mStateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (stateList != null && stateList.size() > 0) {
                    if(position!=0){
                        String UID = stateList.get(position).get_ID();
                        stateStr = UID;
                        userMetadata.setState(UID);
                        new DistrictServiceExecuter("district", UID, mDistrictSpinner).execute();
                    }else{
                        stateStr="";
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mDistrictSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (districtList != null && districtList.size() > 0) {
                    if(position!=0){
                        String UID = districtList.get(position).get_ID();
                        districtStr = UID;
                        userMetadata.setDistrict(UID);
                    }else{
                        districtStr="";
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mPostGraduationSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(postGradList.get(position).get_Name()==null)
                    return;
                String postGraduation = postGradList.get(position).get_ID();
                userMetadata.setPostGraduation(postGraduation);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mGraduationSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(gradList.get(position).get_Name()==null)
                    return;
                String pGraduation = gradList.get(position).get_ID();
                userMetadata.setGraduation(pGraduation);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    private class CommonServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public CommonServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            commonServiceList = commonServicesData;
            if(mRequestType.equalsIgnoreCase("Grad")){
                gradList=commonServiceList;
            }else if(mRequestType.equalsIgnoreCase("Post")){
                postGradList=commonServiceList;
            }
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

    private class StateServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public StateServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            stateList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

    private class DistrictServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public DistrictServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            districtList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            if (progressDialog != null && progressDialog.isShowing())
                progressDialog.dismiss();
            progressDialog = null;
            SpinnerAdapter commonAdapter = new SpinnerAdapter(getActivity(), result);
            commonSpinnerView.setAdapter(commonAdapter);
            mFatherSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Father), getUserData.getFatherTitle()));
            mMonthSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Mother), getUserData.getMotherTitle()));
//            System.out.println("Test===" + userMetadata.getGender());
            mGenderSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Gender), getUserData.getGender()));
            mChildrenSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Children),getUserData.getmHaveChild()));
            mMaritalSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Marital_Status), getUserData.getMaritalStatus()));
            multiSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Hobbies),getUserData.getHobbies()));
            mGraduationSpinner2.setSelection(Util.getPosition(getResources().getStringArray(R.array.CommonGraduation),getUserData.getGraduationType()));
            mPostGraduationSpinner2.setSelection(Util.getPosition(getResources().getStringArray(R.array.CommonGraduation),getUserData.getPostGraduationType()));
            mOccupationSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Occupation),getUserData.getDetailsOfOccupation()));
            mBloodSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Blood_Group),getUserData.getBloodGroup()));
            mBelow10thSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Below10th),getUserData.getBelow10TH()));
            m10thSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Class10th),getUserData.getHighschool()));
            m12thSpinner2.setSelection(Util.getPosition(getResources().getStringArray(R.array.Class12th2), getUserData.getInter()));
            m12thSpinner1.setSelection(Util.getPosition(getResources().getStringArray(R.array.Class10th),getUserData.getBoard()));
//Dynamic
//            mOccupationSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Class10th), getUserData.getClass12TH()));
            mGraduationSpinner1.setSelection(Util.getSpinnerPosition(gradList, getUserData.getGraduation()));
            mPostGraduationSpinner1.setSelection(Util.getSpinnerPosition(postGradList,getUserData.getPostGraduation()));
            mStateSpinner.setSelection(Util.getSpinnerPosition(stateList, getUserData.getState()));
            mDistrictSpinner.setSelection(Util.getSpinnerPosition(districtList, getUserData.getDistrict()));
            mDaySpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Day), getUserData.getmDay()));
            mMonthSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Month_Code), getUserData.getmMonth()));
            mYearSpinner.setSelection(Util.getPosition(getResources().getStringArray(R.array.Year), getUserData.getmYear()));

        }
    }


    private class UpdateUserProfileTask extends AsyncTask<String, Void, UserMetadata> {
        public UpdateUserProfileTask() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(getActivity(), "Fetching UserData", "Please wait...", true, false);
        }

        @Override
        protected UserMetadata doInBackground(String... urls) {
            getUserData = new UserMetadata();
            XMLParser parser = new XMLParser();
            getUserData = parser.userDataParser(getActivity());
            return getUserData;
        }

        @Override
        protected void onPostExecute(UserMetadata result) {
            mUserNameTxt.setText(result.getUserName());
            mFatherNameTxt.setText(result.getFatherName());
            mMotherNameTxt.setText(result.getMotherName());
            mSpouseNameTxt.setText(result.getSpouseName());
            mGotraNameTxt.setText(result.getGotraName());
            mMaternalGotraTxt.setText(result.getMaternalGotraName());
            mChildren1Txt.setText(result.getChild1Name());
            mChildren2Txt.setText(result.getChild2Name());
            mChildren3Txt.setText(result.getChild3Name());
            mChildren4Txt.setText(result.getChild4Name());
            mDepartmentTxt.setText(result.getDesignation());
            mOccupationTxt.setText(result.getOcuupation());
            mPresentAddressTxt.setText(result.getPresentAddress());
            mPermanentAddressTxt.setText(result.getPermanentAddress());
            mPinCodeTxt.setText(result.getPinCode());
            mEmailTxt.setText(result.getEmail());
            mLandLineTxt.setText(result.getLandLine());
            mMobileTxt.setText(result.getMobileNo());
            mAlternatenoTxt.setText(result.getAlternateNo());
            mOtherQualificationTxt.setText(result.getOtherQualification());

        }
    }

}
