package survey.nic.com.survey;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import survey.nic.adapter.CirclePageIndicator;
import survey.nic.adapter.EventDetailPagerAdapter;
import survey.nic.adapter.ReaderViewPagerTransformer;
import survey.nic.parser.EventMetaData;
import survey.nic.parser.XMLParser;

public class EventDetailActivity extends AppCompatActivity {

    EventDetailPagerAdapter mCustomPagerAdapter;
    private Handler handler = new Handler();
    ViewPager mViewPager;
    int position = 0;
    private String eventDate="";
    // the images to display
    int[] imageIDs = {R.drawable.logo, R.drawable.logo, R.drawable.logo,
            R.drawable.logo};

    private String appealString = "The nation is standing at crossroads leading to three paths. \"While one road leads to UPA government which has a record of five years of criminal neglect of development and security, the second leads to those parties whose priority is to somehow stitch up an alliance to come to power. The third road leads to BJP-led NDA which can give the country political stability, development, good governance and security to which it is committed, as it has already been proved during the six years of NDA rule.\"\n" +
            " In all these years, my dream and that of my colleagues was to make India a strong, prosperous nation... There were many who joined me on the way but the closest and most talented comrade through my journey was Advaniji... Having working together, I have been in awe of his wisdom, clarity of thought and his skill to carry people along... He has played a great role in taking BJP to its present heights... His unblemished character and firm commitment and personality...is what the nation needs today.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActionBar abar = getSupportActionBar();
        View viewActionBar = getLayoutInflater().inflate(R.layout.titlebar_xml, null);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("Event");
        abar.setCustomView(viewActionBar, params);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        setContentView(R.layout.fragment_event_detail);
//        TextView content = (TextView) findViewById(R.id.contentTv);
//        content.setText(appealString);
        Intent intent=getIntent();
        eventDate=intent.getStringExtra("EventID");
        new EventServiceExecuter().execute();
    }

    @Override
    public void onResume() {
        super.onResume();
//        handler.postDelayed(runnable, 3000);
    }

    Runnable runnable = new Runnable() {
        public void run() {
            if (position == 4) {
                position = 0;
            }
            mViewPager.setCurrentItem(position++, true);
            handler.postDelayed(runnable, 3000);
        }
    };
    private class EventServiceExecuter extends AsyncTask<String, Void, List<EventMetaData>> {
        ProgressDialog progressDialog;
        public EventServiceExecuter() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(EventDetailActivity.this, "", "Please wait...", true, false);
        }

        @Override
        protected List<EventMetaData> doInBackground(String... urls) {
            XMLParser xmlParser=new XMLParser();
            List<EventMetaData> commonServicesData = new ArrayList<EventMetaData>();
            commonServicesData = xmlParser.eventServiceDataParser("2",eventDate);
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<EventMetaData> result) {
            if(progressDialog!=null&&progressDialog.isShowing()){
                progressDialog.dismiss();
            }
            CirclePageIndicator indicator = (CirclePageIndicator) findViewById(R.id.indicat);
            mCustomPagerAdapter = new EventDetailPagerAdapter(EventDetailActivity.this,result);
            mViewPager = (ViewPager) findViewById(R.id.pager);
            mViewPager.setAdapter(mCustomPagerAdapter);
            mViewPager.setPageTransformer(false, new ReaderViewPagerTransformer(ReaderViewPagerTransformer.TransformType.DEPTH));
            indicator.setViewPager(mViewPager);
        }
    }
}
