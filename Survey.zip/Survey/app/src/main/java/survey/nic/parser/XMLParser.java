package survey.nic.parser;

import android.content.Context;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import survey.nic.com.survey.Constants;
import survey.nic.utility.Util;

/**
 * Created by Yogesh on 2/14/2016.
 */
public class XMLParser {

    public String getXmlFromUrl(String url) {
        String xml = null;

        try {
            // defaultHttpClient
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpGet httpPost = new HttpGet(url);

            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            xml = EntityUtils.toString(httpEntity);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return XML
        return xml;
    }

    public Document getDomElement(String xml){
        Document doc = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(new InputSource(new ByteArrayInputStream(xml.getBytes("utf-8"))));

//            DocumentBuilder db = dbf.newDocumentBuilder();
//            InputSource is = new InputSource();
//            is.setCharacterStream(new StringReader(xml,"UTF-8"));
//            doc = db.parse(is);
        } catch (ParserConfigurationException e) {
            Log.e("Error: ", e.getMessage());
            return null;
        } catch (SAXException e) {
            Log.e("Error: ", e.getMessage());
            return null;
        } catch (IOException e) {
            Log.e("Error: ", e.getMessage());
            return null;
        }
        // return DOM
        return doc;
    }
    public String getValue(Element item, String str) {
        NodeList n = item.getElementsByTagName(str);
        return this.getElementValue(n.item(0));
    }

    public final String getElementValue( Node elem ) {
        Node child;
        if( elem != null){
            if (elem.hasChildNodes()){
                for( child = elem.getFirstChild(); child != null; child = child.getNextSibling() ){
                    if( child.getNodeType() == Node.TEXT_NODE  ){
                        return child.getNodeValue();
                    }
                }
            }
        }
        return "";
    }

    public List<CommonService> commonServiceDataParser(String requestType,String searchvalue){
        String KEY_PARENT_NODE = "row";
        String KEY_CHILD_NODE = "row";
        String KEY_ITEM_ID = "Id";
        String KEY_ITEM_NAME = "Name";
        List<CommonService> commonServicesData=new ArrayList<CommonService>();
        String mURL= Constants.commonServiceURL+"Type="+requestType+"&SearchValue="+searchvalue;
        try {
            final String encodedURL = URLEncoder.encode(mURL, "UTF-8");
//            XMLParser parser = new XMLParser();
            System.out.println("Url====" + mURL);
            CommonService commonService = new CommonService();
            commonService.set_ID("-1");
            if(requestType.equalsIgnoreCase("Occupation")){
                commonService.set_Name("Select Occupation");
            }else if(requestType.equalsIgnoreCase("Post")){
                commonService.set_Name("Select Post Grad.");
            }else if(requestType.equalsIgnoreCase("Grad")){
                commonService.set_Name("Select Graduation");
            }else if(requestType.equalsIgnoreCase("Marital")){
                commonService.set_Name("Select Marital Status");
            }else if(requestType.equalsIgnoreCase("state")){
                commonService.set_Name("--Select State--");
            }else if(requestType.equalsIgnoreCase("district")){
                commonService.set_Name("--Select District--");
            }
//            commonService.set_Name("--Select--");
            commonServicesData.add(commonService);
            String xml = getXmlFromUrl(mURL); // getting XML
            Document doc = getDomElement(xml); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                commonService = new CommonService();
                Element e = (Element) nl.item(i);
                String _ID = getValue(e, KEY_ITEM_ID);
                commonService.set_ID(_ID);
                String Name = getValue(e, KEY_ITEM_NAME);
                commonService.set_Name(Name);
                commonServicesData.add(commonService);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return commonServicesData;
    }
    public List<EventMetaData> eventServiceDataParser(String requestType,String eventID){
        String KEY_PARENT_NODE = "row";
        String KEY_ITEM_Eventtext = "Eventtext";
        String KEY_ITEM_EventDate = "EventDate";
        String KEY_ITEM_Image = "Image";
        String KEY_ITEM_EventDateID = "EventDateID";
        List<EventMetaData> eventServicesData=new ArrayList<EventMetaData>();
        String mURL= Constants.eventServiceURL+"type="+requestType+"&Eventid="+eventID;
        try {
            final String encodedURL = URLEncoder.encode(mURL, "UTF-8");
            XMLParser parser = new XMLParser();
            System.out.println("Url====" + mURL);
            String xml = parser.getXmlFromUrl(mURL); // getting XML
            Document doc = parser.getDomElement(xml); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                EventMetaData eventService = new EventMetaData();
                Element e = (Element) nl.item(i);
                String Text = parser.getValue(e, KEY_ITEM_Eventtext);
                eventService.setEventtext(Text);
                String eventDate = parser.getValue(e, KEY_ITEM_EventDate);
                eventService.setEventDate(eventDate);
                String eventImage = parser.getValue(e, KEY_ITEM_Image);
                eventService.setImage(eventImage);
                String eventDateID = parser.getValue(e, KEY_ITEM_EventDateID);
                eventService.setEventDateID(eventDateID);
                eventServicesData.add(eventService);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return eventServicesData;
    }

    public UserMetadata userDataParser(Context context){
        String KEY_PARENT_NODE = "row";
        UserMetadata user=null;
        String mURL= Constants.getUserServiceURL+"type=1&UserID="+ Util.getUid(context);
        try {
            final String encodedURL = URLEncoder.encode(mURL, "UTF-8");
//            XMLParser parser = new XMLParser();
            System.out.println("Url====" + mURL);
            String xml = getXmlFromUrl(mURL); // getting XML
            Document doc = getDomElement(xml); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                user = new UserMetadata();
                Element e = (Element) nl.item(i);
                String UserName = getValue(e, "User_Name");
                user.setUserName(UserName);
                String Father_Name = getValue(e, "Father_Name");
                user.setFatherName(Father_Name);
                String Mother_Name = getValue(e, "Mother_Name");
                user.setMotherName(Mother_Name);
                String Gender = getValue(e, "Gender");
                user.setGender(Gender);
                String Dob = getValue(e, "Dob");
                user.setDob(Dob);
                String Marital_status = getValue(e, "Marital_status");
                user.setMaritalStatus(Marital_status);
                String Blood_group = getValue(e, "Blood_group");
                user.setBloodGroup(Blood_group);
                String Gotra = getValue(e, "Gotra");
                user.setGotraName(Gotra);
                String Occupation = getValue(e, "Occupation");
                user.setOcuupation(Occupation);
                String Detailsofoccupation = getValue(e, "Detailsofoccupation");
                user.setDetailsOfOccupation(Detailsofoccupation);
                String Presentaddress = getValue(e, "Presentaddress");
                user.setPresentAddress(Presentaddress);
                String State = getValue(e, "State");
                user.setState(State);
                String District = getValue(e, "District");
                user.setDistrict(District);
                String Pincode = getValue(e, "Pincode");
                user.setPinCode(Pincode);
                String Email = getValue(e, "Email");
                user.setEmail(Email);
                String Scode = getValue(e, "Scode");
                user.setmScode(Scode);
                String Telephone_no = getValue(e, "Telephone_no");
                user.setLandLine(Telephone_no);
                String Mobile = getValue(e, "Mobile");
                user.setMobileNo(Mobile);
                String Postgraduate = getValue(e, "Postgraduate");
                user.setPostGraduation(Postgraduate);
                String Graduation = getValue(e, "Graduation");
                user.setGraduation(Graduation);
                String Highschool = getValue(e, "Highschool");
                user.setHighschool(Highschool);
                String Otherd = getValue(e, "Otherd");
                user.setOtherQualification(Otherd);
                String Below10 = getValue(e, "Below10");
                user.setBelow10TH(Below10);
                String Inter = getValue(e, "Inter");
                user.setInter(Inter);
                String Createddate = getValue(e, "Createddate");
                user.setCreatedDate(Createddate);
                String Designation = getValue(e, "Designation");
                user.setDesignation(Designation);
                String Permenentaddress = getValue(e, "Permenentaddress");
                user.setPermanentAddress(Permenentaddress);
                String Hobbies = getValue(e, "Hobbies");
                user.setHobbies(Hobbies);
                String Altno = getValue(e, "Altno");
                user.setAlternateNo(Altno);
                String Mgotra = getValue(e, "Mgotra");
                user.setMaternalGotraName(Mgotra);
                String Board = getValue(e, "Board");
                user.setBoard(Board);
                String Pqtype = getValue(e, "Pqtype");
                user.setPostGraduationType(Pqtype);
                String Qtype = getValue(e, "Qtype");
                user.setGraduationType(Qtype);
                String Ftitle = getValue(e, "Ftitle");
                user.setFatherTitle(Ftitle);
                String MTitle = getValue(e, "MTitle");
                user.setMotherTitle(MTitle);
                String Spouse_name = getValue(e, "Spouse_name");
                user.setSpouseName(Spouse_name);
                String hychild = getValue(e, "hychild");
                user.setmHaveChild(hychild);
                String chil1 = getValue(e, "chil1");
                user.setChild1Name(chil1);
                String child2 = getValue(e, "child2");
                user.setChild2Name(child2);
                String child3 = getValue(e, "child3");
                user.setChild3Name(child3);
                String child4 = getValue(e, "child4");
                user.setChild4Name(child4);
                String DYEAR = getValue(e, "DYEAR");
                user.setmYear(DYEAR);
                String DMAONTH = getValue(e, "DMAONTH");
                user.setmMonth(DMAONTH);
                String DDAY = getValue(e, "DDAY");
                user.setmDay(DDAY);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
}
