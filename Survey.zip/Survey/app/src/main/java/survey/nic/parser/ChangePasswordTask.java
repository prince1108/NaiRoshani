package survey.nic.parser;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

import survey.nic.com.survey.Constants;
import survey.nic.com.survey.MainActivity;
import survey.nic.utility.Util;

/**
 * Created by Ravi on 9/8/2016.
 */
public class ChangePasswordTask extends AsyncTask<String, Void, String> {
    private Context mContext;
    private String dataString = "";
    String resultText="";
    ProgressDialog progressDialog;
    public ChangePasswordTask(Context context, String data) {
        this.mContext = context;
        this.dataString = data;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = ProgressDialog.show(mContext, "Change Password", "Please wait...", true, false);
    }

    @Override
    protected String doInBackground(String... params) {
        String response = "";
        String result = "";
        BufferedReader reader = null;
        String KEY_PARENT_NODE = "row";
        String KEY_ITEM_RESULT = "Result";
        String KEY_ITEM_RESULT_TEXT = "ResultText";
        System.out.println("Request====" + dataString);
        try {
            // Defined URL  where to send data
            URL url = new URL(Constants.changePasswordServiceURL);
            // Send POST data request
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(dataString);
            wr.flush();
            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
            }
            response = sb.toString();
            System.out.println("Response====" + response);

            XMLParser xmlParser = new XMLParser();
            Document doc = xmlParser.getDomElement(response); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                Element e = (Element) nl.item(i);
                result = xmlParser.getValue(e, KEY_ITEM_RESULT);
                resultText = xmlParser.getValue(e, KEY_ITEM_RESULT_TEXT);
            }
        } catch (Exception ex) {

        } finally {
            try {
                reader.close();
            } catch (Exception ex) {
            }
        }
        // Show response on activity
        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        progressDialog.dismiss();
        if(s.equalsIgnoreCase("1")){
            Util.alertMessage(mContext, resultText);
        }
    }
}