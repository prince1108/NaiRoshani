package survey.nic.parser;

/**
 * Created by shankar_r on 8/29/2016.
 */
public class UserMetadata {

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }

    public String getGotraName() {
        return gotraName;
    }

    public void setGotraName(String gotraName) {
        this.gotraName = gotraName;
    }

    public String getMaternalGotraName() {
        return maternalGotraName;
    }

    public void setMaternalGotraName(String maternalGotraName) {
        this.maternalGotraName = maternalGotraName;
    }

    public String getChild1Name() {
        return child1Name;
    }

    public void setChild1Name(String child1Name) {
        this.child1Name = child1Name;
    }

    public String getChild2Name() {
        return child2Name;
    }

    public void setChild2Name(String child2Name) {
        this.child2Name = child2Name;
    }

    public String getChild3Name() {
        return child3Name;
    }

    public void setChild3Name(String child3Name) {
        this.child3Name = child3Name;
    }

    public String getChild4Name() {
        return child4Name;
    }

    public void setChild4Name(String child4Name) {
        this.child4Name = child4Name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getOcuupation() {
        return ocuupation;
    }

    public void setOcuupation(String ocuupation) {
        this.ocuupation = ocuupation;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLandLine() {
        return landLine;
    }

    public void setLandLine(String landLine) {
        this.landLine = landLine;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getAlternateNo() {
        return alternateNo;
    }

    public void setAlternateNo(String alternateNo) {
        this.alternateNo = alternateNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }





    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getDetailsOfOccupation() {
        return detailsOfOccupation;
    }

    public void setDetailsOfOccupation(String detailsOfOccupation) {
        this.detailsOfOccupation = detailsOfOccupation;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getBelow10TH() {
        return below10TH;
    }

    public void setBelow10TH(String below10TH) {
        this.below10TH = below10TH;
    }

    public String getClass10TH() {
        return class10TH;
    }

    public void setClass10TH(String class10TH) {
        this.class10TH = class10TH;
    }

    public String getClass12TH() {
        return class12TH;
    }

    public void setClass12TH(String class12TH) {
        this.class12TH = class12TH;
    }

    public String getGraduation() {
        return graduation;
    }

    public void setGraduation(String graduation) {
        this.graduation = graduation;
    }

    public String getPostGraduation() {
        return postGraduation;
    }

    public void setPostGraduation(String postGraduation) {
        this.postGraduation = postGraduation;
    }

    public String getOtherQualification() {
        return otherQualification;
    }

    public void setOtherQualification(String otherQualification) {
        this.otherQualification = otherQualification;
    }

    public String getmHaveChild() {
        return mHaveChild;
    }

    public void setmHaveChild(String mHaveChild) {
        this.mHaveChild = mHaveChild;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    private String serialNo;
    private String mHaveChild;
    private String motherTitle;
    private String fatherTitle;
    private String graduationType;
    private String Reg_no;
    private String Profile_Image;

    public Boolean getIsClicked() {
        return isClicked;
    }

    public void setIsClicked(Boolean isClicked) {
        this.isClicked = isClicked;
    }

    private Boolean isClicked=false;
    public String getReg_no() {
        return Reg_no;
    }

    public void setReg_no(String reg_no) {
        Reg_no = reg_no;
    }

    public String getProfile_Image() {
        return Profile_Image;
    }

    public void setProfile_Image(String profile_Image) {
        Profile_Image = profile_Image;
    }

    public String getInter() {
        return Inter;
    }

    public void setInter(String inter) {
        Inter = inter;
    }

    public String getHighschool() {
        return Highschool;
    }

    public void setHighschool(String highschool) {
        Highschool = highschool;
    }

    private String Inter;
    private String Highschool;
    public String getMotherTitle() {
        return motherTitle;
    }

    public void setMotherTitle(String motherTitle) {
        this.motherTitle = motherTitle;
    }

    public String getFatherTitle() {
        return fatherTitle;
    }

    public void setFatherTitle(String fatherTitle) {
        this.fatherTitle = fatherTitle;
    }

    public String getGraduationType() {
        return graduationType;
    }

    public void setGraduationType(String graduationType) {
        this.graduationType = graduationType;
    }

    public String getPostGraduationType() {
        return postGraduationType;
    }

    public void setPostGraduationType(String postGraduationType) {
        this.postGraduationType = postGraduationType;
    }

    public String getmClass12th2() {
        return mClass12th2;
    }

    public void setmClass12th2(String mClass12th2) {
        this.mClass12th2 = mClass12th2;
    }

    public String getmYear() {
        return mYear;
    }

    public void setmYear(String mYear) {
        this.mYear = mYear;
    }

    public String getmMonth() {
        return mMonth;
    }

    public void setmMonth(String mMonth) {
        this.mMonth = mMonth;
    }

    public String getmDay() {
        return mDay;
    }

    public void setmDay(String mDay) {
        this.mDay = mDay;
    }

    public String getmGender() {
        return mGender;
    }

    public void setmGender(String mGender) {
        this.mGender = mGender;
    }

    private String postGraduationType;
    private String mClass12th2;
    private String mYear;
    private String mMonth;
    private String mDay;
    private String mGender;

    public String getmScode() {
        return mScode;
    }

    public void setmScode(String mScode) {
        this.mScode = mScode;
    }

    private String mScode;
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    private String designation;
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    private String createdDate;

    public String getBoard() {
        return board;
    }

    public void setBoard(String board) {
        this.board = board;
    }

    private String board;
    private String dob;
    private String userName;
    private String fatherName;
    private String motherName;
    private String spouseName;
    private String gotraName;
    private String maternalGotraName;
    private String child1Name;
    private String child2Name;
    private String child3Name;
    private String child4Name;
    private String department;
    private String ocuupation;
    private String presentAddress;
    private String permanentAddress;
    private String pinCode;
    private String email;
    private String landLine;
    private String mobileNo;
    private String alternateNo;
    private String gender;
    private String maritalStatus;
    private String bloodGroup;
    private String detailsOfOccupation;
    private String hobbies;
    private String state;
    private String district;
    private String below10TH;
    private String class10TH;
    private String class12TH;
    private String graduation;
    private String postGraduation;
    private String otherQualification;
}
