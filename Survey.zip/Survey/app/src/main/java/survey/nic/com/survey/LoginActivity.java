package survey.nic.com.survey;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import survey.nic.parser.LoginTask;
import survey.nic.utility.Util;

public class LoginActivity extends AppCompatActivity {
    //user UPKAN1983292016
    //passs  SYKNCN6N
    private Button logingBtn;
    private TextView homeTxt,signupTxt;
    String againPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initViews();
    }

    private void initViews() {
        homeTxt= (TextView) findViewById(R.id.homeTxt);
        signupTxt= (TextView) findViewById(R.id.signupTxt);
        LinearLayout mForgotpassword = (LinearLayout) findViewById(R.id.forgot_password);
        LinearLayout mSignup = (LinearLayout) findViewById(R.id.signup);
        final EditText userNameTxt = (EditText) findViewById(R.id.username_edit);
        final EditText passwordTxt = (EditText) findViewById(R.id.password_edit);
        String homeStr="<a href='' color='#315575'>Home</a>";
        homeTxt.setText(Html.fromHtml(homeStr));
        String signupStr="<a href='' color='#315575'>Register New User</a>";
        signupTxt.setText(Html.fromHtml(signupStr));
        logingBtn = (Button) findViewById(R.id.logingBtn);

        mForgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
            }
        });

        logingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password= Util.MD5(passwordTxt.getText().toString());
                System.out.println("Conversion===="+password);
                java.util.Random rng = new java.util.Random(); //Provide a seed if you want the same ones every time
                final long first14 = (rng.nextLong() % 100000000000000L) + 5200000000000000L;
                System.out.println("Number===="+first14);
                againPassword=Util.MD5(first14+"" + "" + password);
                System.out.println("Conversion===="+againPassword);
                new LoginTask(LoginActivity.this,"type=1&Userid="+userNameTxt.getText().toString()+"&Password="+againPassword+"&UniquID="+first14+"").execute();
            }
        });
        signupTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
            }
        });


    }
}
