package survey.nic.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import survey.nic.com.survey.R;
import survey.nic.parser.CommonService;

/**
 * Created by ravi on 1/14/2016.
 */
public class SpinnerAdapter extends BaseAdapter {
    private Context mcontext;
    private static LayoutInflater inflater = null;
    List<CommonService> dataList;

    public SpinnerAdapter(Context context, List<CommonService> commonServicesData) {
        this.mcontext = context;
        this.dataList = commonServicesData;
        inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        View rowView;
        rowView = inflater.inflate(R.layout.spinner_item, null);
        TextView itemName=(TextView)rowView.findViewById(R.id.itemNameTxt);
        itemName.setText(dataList.get(position).get_Name());
        return rowView;
    }


}
