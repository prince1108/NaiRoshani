package survey.nic.com.survey;

/**
 * Created by Ravi on 8/28/2016.
 */
public class Constants {
    public static final String baseURL="http://www.nairoshani.com/";
    public static final String registrationServiceURL=baseURL+"regservices.asmx/GetData?";
    public static final String commonServiceURL=baseURL+"commonservice.asmx/GetData?";
    public static final String eventServiceURL=baseURL+"EventsDetails.asmx/GetAllevent?";
    public static final String searchUserServiceURL=baseURL+"searchuser.asmx/GetData?";
    public static final String getUserServiceURL=baseURL+"searchuser.asmx/GetSingleData?";
    public static final String loginServiceURL=baseURL+"Logindetail.asmx/GetData?";
    public static final String changePasswordServiceURL=baseURL+"changepwd.asmx/ChangePassword?";
    public static final String feedbackServiceURL=baseURL+"feedbacksvc.asmx/AddFeedback?";

}
