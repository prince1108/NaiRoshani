package survey.nic.parser;

/**
 * Created by Ravi on 9/20/2016.
 */
public class EventMetaData {
    private String Eventtext="";

    public String getEventDate() {
        return EventDate;
    }

    public void setEventDate(String eventDate) {
        EventDate = eventDate;
    }

    public String getEventtext() {
        return Eventtext;
    }

    public void setEventtext(String eventtext) {
        Eventtext = eventtext;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getEventDateID() {
        return EventDateID;
    }

    public void setEventDateID(String eventDateID) {
        EventDateID = eventDateID;
    }

    private String EventDate="";
    private String Image="";
    private String EventDateID="";
}
