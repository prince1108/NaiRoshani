package survey.nic.com.survey;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import survey.nic.adapter.SpinnerAdapter;
import survey.nic.parser.CheckConnection;
import survey.nic.parser.CommonService;
import survey.nic.parser.UserMetadata;
import survey.nic.parser.UserRegistrationTask;
import survey.nic.parser.XMLParser;
import survey.nic.utility.Util;

public class RegistrationActivity extends AppCompatActivity {

    private String genderStr = "", monthStr = "", dayStr = "", yearStr = "", maritalStr = "", haveuChildStr = "", detailofOccupationStr = "", hobbiesStr = "-1", stateStr = "", districtStr = "";
    protected Spinner mFatherSpinner, mMotherSpinner, mGenderSpinner, mBloodSpinner;
    protected Spinner mMonthSpinner, mDaySpinner, mYearSpinner, mMaritalSpinner;
    protected Spinner mChildrenSpinner, mOccupationSpinner;//mHobbiesSpinner
    protected Spinner mStateSpinner, mDistrictSpinner, mGraduationSpinner1;
    protected Spinner mBelow10thSpinner, m10thSpinner, m12thSpinner1, m12thSpinner2;
    protected Spinner mPostGraduationSpinner1, mPostGraduationSpinner2, mGraduationSpinner2;
    MultiSpinner multiSpinner;
    protected EditText mUserNameTxt, alternatemobileSTDTxt, mFatherNameTxt, mMotherNameTxt, mSpouseNameTxt, mGotraNameTxt, mMobileSTDTxt;
    protected EditText mMaternalGotraTxt, mChildren1Txt, mChildren2Txt, mChildren3Txt, mChildren4Txt;
    protected EditText mDepartmentTxt, mOccupationTxt, mPresentAddressTxt, mPermanentAddressTxt, landlineSTDTxt;
    protected EditText mPinCodeTxt, mEmailTxt, mLandLineTxt, mMobileTxt, mAlternatenoTxt, mOtherQualificationTxt;
    protected Button mSubmitBtn;
    protected CheckBox checkBox;
    private List<CommonService> stateList = new ArrayList<CommonService>();
    private List<CommonService> commonServiceList = new ArrayList<CommonService>();
    private List<CommonService> gradServiceList = new ArrayList<CommonService>();
    private List<CommonService> postGradServiceList = new ArrayList<CommonService>();
    private List<CommonService> districtList = new ArrayList<CommonService>();
    UserMetadata userMetadata = new UserMetadata();
    ProgressDialog progressDialog;
    TextView depatrtmentandDesignationTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActionBar abar = getSupportActionBar();
        View viewActionBar = getLayoutInflater().inflate(R.layout.header_xml, null);
//        ActionBar.LayoutParams params = new ActionBar.LayoutParams(
//                ActionBar.LayoutParams.MATCH_PARENT,
//                ActionBar.LayoutParams.WRAP_CONTENT,
//                Gravity.RIGHT);
        TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
        textviewTitle.setText("User Registration");
        abar.setCustomView(viewActionBar);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(false);
        setContentView(R.layout.activity_registration);
        initSpinnerViews();
        initTextViews();
        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = mEmailTxt.getText().toString().trim();
                final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                CheckConnection checkConnection = new CheckConnection(RegistrationActivity.this);
                boolean isConnected = checkConnection.isNetworkAvailable(RegistrationActivity.this);
                String dataString = getValueFromViews();
                if (mUserNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter your name!");
                } else if (mFatherNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter father name!");
                } else if (mMotherNameTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter mother name!");
                } else if (genderStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please select gender!");
                } else if (monthStr.equalsIgnoreCase("") || dayStr.equalsIgnoreCase("") || yearStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please select date of birth!");
                } else if (maritalStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please select marital status!");
                } else if (haveuChildStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please select have you children!");
                } else if (haveuChildStr.equalsIgnoreCase("yes")&&mChildren1Txt.getText().toString().equalsIgnoreCase("") && mChildren2Txt.getText().toString().equalsIgnoreCase("") && mChildren3Txt.getText().toString().equalsIgnoreCase("") && mChildren4Txt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter at least one name of children!");
                } else if (detailofOccupationStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter detail of occupation!");
                } else if (mDepartmentTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter department and designation!");
                } else if (mOccupationTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please select occupation!");
                } else if (hobbiesStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "Select Hobbies");
                } else if (mPresentAddressTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter present address!");
                } else if (mPermanentAddressTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter permanent address!");
                } else if (stateStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "Select State");
                } else if (districtStr.equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "Select District");
                } else if (mMobileTxt.getText().toString().equalsIgnoreCase("")) {
                    Util.alertMessage(RegistrationActivity.this, "please enter mobile no!");
                } else if (!email.matches(emailPattern)) {
                    Util.alertMessage(RegistrationActivity.this, "please enter valid email address!");
                } else if (isConnected) {
                    new UserRegistrationTask(RegistrationActivity.this, dataString).execute();
                } else {
                    Util.alertMessage(RegistrationActivity.this, "please check internet connection!");
                }
            }
        });
    }

    private String getValueFromViews() {
        userMetadata.setUserName(mUserNameTxt.getText().toString());
        userMetadata.setFatherName(mFatherNameTxt.getText().toString());
        userMetadata.setMotherName(mMotherNameTxt.getText().toString());
        userMetadata.setSpouseName(mSpouseNameTxt.getText().toString());
        userMetadata.setGotraName(mGotraNameTxt.getText().toString());
        userMetadata.setMaternalGotraName(mMaternalGotraTxt.getText().toString());
        userMetadata.setChild1Name(mChildren1Txt.getText().toString());
        userMetadata.setChild2Name(mChildren2Txt.getText().toString());
        userMetadata.setChild3Name(mChildren3Txt.getText().toString());
        userMetadata.setChild4Name(mChildren4Txt.getText().toString());
        userMetadata.setDepartment(mDepartmentTxt.getText().toString());
        userMetadata.setOcuupation(mOccupationTxt.getText().toString());
        userMetadata.setPresentAddress(mPresentAddressTxt.getText().toString());
        userMetadata.setPermanentAddress(mPermanentAddressTxt.getText().toString());
        userMetadata.setPinCode(mPinCodeTxt.getText().toString());
        userMetadata.setEmail(mEmailTxt.getText().toString());
        userMetadata.setLandLine(mLandLineTxt.getText().toString());
        userMetadata.setMobileNo(mMobileTxt.getText().toString());
        userMetadata.setAlternateNo(mAlternatenoTxt.getText().toString());
        userMetadata.setOtherQualification(mOtherQualificationTxt.getText().toString());


        StringBuilder requestBuilder = new StringBuilder();
        requestBuilder.append("uid=");
        requestBuilder.append("-1");
        requestBuilder.append("&type=");
        requestBuilder.append("insertmob");
        requestBuilder.append("&UName=");
        requestBuilder.append(userMetadata.getUserName());
        requestBuilder.append("&FNameTitle=");
        requestBuilder.append(userMetadata.getFatherTitle());
        requestBuilder.append("&FName=");
        requestBuilder.append(userMetadata.getFatherName());
        requestBuilder.append("&MNameTitle=");
        requestBuilder.append(userMetadata.getMotherTitle());
        requestBuilder.append("&MName=");
        requestBuilder.append(userMetadata.getMotherName());
        requestBuilder.append("&Gender=");
        requestBuilder.append(userMetadata.getmGender());
        requestBuilder.append("&BirthMonth=");
        requestBuilder.append(userMetadata.getmMonth());
        requestBuilder.append("&BirthDay=");
        requestBuilder.append(userMetadata.getmDay());
        requestBuilder.append("&BirthYear=");
        requestBuilder.append(userMetadata.getmYear());
        requestBuilder.append("&MaritalStatus=");
        requestBuilder.append(userMetadata.getMaritalStatus());
        requestBuilder.append("&SpName=");
        requestBuilder.append(userMetadata.getSpouseName());
        requestBuilder.append("&BloodGroup=");
        requestBuilder.append(userMetadata.getBloodGroup());
        requestBuilder.append("&Gotra=");
        requestBuilder.append(userMetadata.getGotraName());
        requestBuilder.append("&MetGotra=");
        requestBuilder.append(userMetadata.getMaternalGotraName());
        requestBuilder.append("&HaveYChildren=");//new added
        requestBuilder.append("No");//new added
        requestBuilder.append("&ChildName1=");
        requestBuilder.append(userMetadata.getChild1Name());
        requestBuilder.append("&ChildName2=");
        requestBuilder.append(userMetadata.getChild2Name());
        requestBuilder.append("&ChildName3=");
        requestBuilder.append(userMetadata.getChild3Name());
        requestBuilder.append("&ChildName4=");
        requestBuilder.append(userMetadata.getChild4Name());
        requestBuilder.append("&DetailOfOccupation=");
        requestBuilder.append(userMetadata.getDetailsOfOccupation());
        requestBuilder.append("&DeptDesig=");
        requestBuilder.append(userMetadata.getDepartment());
        requestBuilder.append("&Occupation=");
        requestBuilder.append(userMetadata.getOcuupation());
        requestBuilder.append("&HobInt=");
        requestBuilder.append(userMetadata.getHobbies());
        requestBuilder.append("&PresAddress=");
        requestBuilder.append(userMetadata.getPresentAddress());
        requestBuilder.append("&SameAddress=");
        requestBuilder.append("true");//TODO
        requestBuilder.append("&PermAddress=");
        requestBuilder.append(userMetadata.getPermanentAddress());
        requestBuilder.append("&State=");
        requestBuilder.append(userMetadata.getState());
        requestBuilder.append("&District=");
        requestBuilder.append(userMetadata.getDistrict());
        requestBuilder.append("&PinCode=");
        requestBuilder.append(userMetadata.getPinCode());
        requestBuilder.append("&EmailAdd=");
        requestBuilder.append(userMetadata.getEmail());
        requestBuilder.append("&TelePhoneNo1=");
        requestBuilder.append(landlineSTDTxt.getText().toString());
        requestBuilder.append("&TelePhoneNo2=");
        requestBuilder.append(mLandLineTxt.getText().toString());
        requestBuilder.append("&Mobile1=");
        requestBuilder.append(mMobileSTDTxt.getText().toString());
        requestBuilder.append("&Mobile2=");
        requestBuilder.append(userMetadata.getMobileNo());
        requestBuilder.append("&AltMobileNo1=");
        requestBuilder.append(alternatemobileSTDTxt.getText().toString());
        requestBuilder.append("&AltMobileNo2=");
        requestBuilder.append(userMetadata.getAlternateNo());
        requestBuilder.append("&below10th=");
        requestBuilder.append(userMetadata.getBelow10TH());
        requestBuilder.append("&Class10th=");
        requestBuilder.append(userMetadata.getClass10TH());
        requestBuilder.append("&Class12thboard=");
        requestBuilder.append(userMetadata.getClass12TH());
        requestBuilder.append("&Class12thType=");
        requestBuilder.append(userMetadata.getmClass12th2());
        requestBuilder.append("&GraduationCourse=");
        requestBuilder.append(userMetadata.getGraduation());
        requestBuilder.append("&GraduationType=");
        requestBuilder.append(userMetadata.getGraduationType());
        requestBuilder.append("&PGraduationCourse=");
        requestBuilder.append(userMetadata.getPostGraduation());
        requestBuilder.append("&PGraduationType=");
        requestBuilder.append(userMetadata.getPostGraduationType());
        requestBuilder.append("&OtherQualification=");
        requestBuilder.append(userMetadata.getOtherQualification());
        requestBuilder.append("&IpAddress=");
        requestBuilder.append("192.12.45.65");
        return requestBuilder.toString();

    }

    private void initTextViews() {
        depatrtmentandDesignationTextView = (TextView) findViewById(R.id.depatrtmentandDesignationTextView);
        checkBox = (CheckBox) findViewById(R.id.checkbox);
        mSubmitBtn = (Button) findViewById(R.id.submitBtn);
        mUserNameTxt = (EditText) findViewById(R.id.userNameTxt);
        mFatherNameTxt = (EditText) findViewById(R.id.fatherNameTxt);
        mMotherNameTxt = (EditText) findViewById(R.id.motherNameTxt);
        mSpouseNameTxt = (EditText) findViewById(R.id.spouseNameTxt);
        mGotraNameTxt = (EditText) findViewById(R.id.gotraTxt);
        mMaternalGotraTxt = (EditText) findViewById(R.id.metrnalgotraTxt);
        mChildren1Txt = (EditText) findViewById(R.id.children1Txt);
        mChildren2Txt = (EditText) findViewById(R.id.children2Txt);
        mChildren3Txt = (EditText) findViewById(R.id.children3Txt);
        mChildren4Txt = (EditText) findViewById(R.id.children4Txt);
        mDepartmentTxt = (EditText) findViewById(R.id.departmentTxt);
        mOccupationTxt = (EditText) findViewById(R.id.occupationTxt);
        mPresentAddressTxt = (EditText) findViewById(R.id.presentaddressTxt);
        mPermanentAddressTxt = (EditText) findViewById(R.id.permanentaddressTxt);
        mPinCodeTxt = (EditText) findViewById(R.id.pincodeTxt);
        mEmailTxt = (EditText) findViewById(R.id.emailaddressTxt);
        landlineSTDTxt = (EditText) findViewById(R.id.landlineSTDTxt);
        mLandLineTxt = (EditText) findViewById(R.id.landlineTxt);
        mMobileTxt = (EditText) findViewById(R.id.mobileTxt);
        mMobileSTDTxt = (EditText) findViewById(R.id.mobileSTDTxt);
        mAlternatenoTxt = (EditText) findViewById(R.id.alternatemobileTxt);
        alternatemobileSTDTxt = (EditText) findViewById(R.id.alternatemobileSTDTxt);
        mOtherQualificationTxt = (EditText) findViewById(R.id.otherqualificationTxt);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mPermanentAddressTxt.setText(mPresentAddressTxt.getText().toString());
                } else {
                    mPermanentAddressTxt.setText("");
                }
            }
        });
    }

    private void initSpinnerViews() {
        /*
        @Personnel Information Spinners
         */
        multiSpinner = (MultiSpinner) findViewById(R.id.multispinner);
        mFatherSpinner = (Spinner) findViewById(R.id.fatherSpin);
        mMotherSpinner = (Spinner) findViewById(R.id.motherSpin);
        mGenderSpinner = (Spinner) findViewById(R.id.genderSpin);
        mMonthSpinner = (Spinner) findViewById(R.id.monthSpin);
        mDaySpinner = (Spinner) findViewById(R.id.daySpin);
        mYearSpinner = (Spinner) findViewById(R.id.yearSpin);
        mMaritalSpinner = (Spinner) findViewById(R.id.maritalSpin);//TODO
        mBloodSpinner = (Spinner) findViewById(R.id.bloodSpin);
        mChildrenSpinner = (Spinner) findViewById(R.id.childrenSpin);
        mOccupationSpinner = (Spinner) findViewById(R.id.detailsOccupationSpin);//TODO
//        mHobbiesSpinner = (Spinner) findViewById(R.id.multispinner);
        /*
        @Address Spinners
         */
        mStateSpinner = (Spinner) findViewById(R.id.stateSpin);//TODO
        mDistrictSpinner = (Spinner) findViewById(R.id.districtSpin);//TODO
        /*
        @Qualification Spinners
         */
        mBelow10thSpinner = (Spinner) findViewById(R.id.below10thSpin);
        m10thSpinner = (Spinner) findViewById(R.id.tenthclassSpin);
        m12thSpinner1 = (Spinner) findViewById(R.id.twelthclass1Spin);
        m12thSpinner2 = (Spinner) findViewById(R.id.twelthclass2Spin);
        mPostGraduationSpinner1 = (Spinner) findViewById(R.id.postgrad1Spin);//TODO
        mPostGraduationSpinner2 = (Spinner) findViewById(R.id.postgrad2Spin);
        mGraduationSpinner1 = (Spinner) findViewById(R.id.grad1Spin);//TODO
        mGraduationSpinner2 = (Spinner) findViewById(R.id.grad2Spin);
        setPersonnelSpinnerData();
    }

    private void setPersonnelSpinnerData() {
        ArrayAdapter mFatherAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Father));
        mFatherSpinner.setAdapter(mFatherAdapter);

        mFatherSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mFatherTitle = getResources().getStringArray(R.array.Father)[position];
                userMetadata.setFatherTitle(mFatherTitle);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mMotherAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Mother));
        mMotherSpinner.setAdapter(mMotherAdapter);
        mMotherSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mMotherTitle = getResources().getStringArray(R.array.Mother)[position];
                userMetadata.setMotherTitle(mMotherTitle);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mGenderAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Gender));
        mGenderSpinner.setAdapter(mGenderAdapter);
        mGenderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mGender = getResources().getStringArray(R.array.Gender)[position];
                if (position != 0) {
                    genderStr = mGender;
                    userMetadata.setmGender(mGender);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mMonthAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Month));
        mMonthSpinner.setAdapter(mMonthAdapter);
        mMonthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mMonth = getResources().getStringArray(R.array.Month_Code)[position];
                if (position != 0) {
                    monthStr = mMonth;
                    userMetadata.setmMonth(mMonth);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mDayAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Day));
        mDaySpinner.setAdapter(mDayAdapter);
        mDaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mDay = getResources().getStringArray(R.array.Day)[position];
                if (position != 0) {
                    dayStr = mDay;
                    userMetadata.setmDay(mDay);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mYearAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Year));
        mYearSpinner.setAdapter(mYearAdapter);
        mYearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mYear = getResources().getStringArray(R.array.Year)[position];
                if (position != 0) {
                    yearStr = mYear;
                    userMetadata.setmYear(mYear);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mBloodGroupAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Blood_Group));
        mBloodSpinner.setAdapter(mBloodGroupAdapter);
        mBloodSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mBloodGroup = getResources().getStringArray(R.array.Blood_Group)[position];
                userMetadata.setBloodGroup(mBloodGroup);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mChildrenGroupAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Children));
        mChildrenSpinner.setAdapter(mChildrenGroupAdapter);
        mChildrenSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mHaveChild = getResources().getStringArray(R.array.Children)[position];
                if (position == 1) {
                    findViewById(R.id.childrenLayout).setVisibility(View.VISIBLE);
                    haveuChildStr = mHaveChild;
                    userMetadata.setmHaveChild(mHaveChild);
                } else {
                    haveuChildStr = mHaveChild;
                    findViewById(R.id.childrenLayout).setVisibility(View.GONE);
                    mChildren1Txt.setText("");
                    mChildren2Txt.setText("");
                    mChildren3Txt.setText("");
                    mChildren4Txt.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mHobbiesAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Hobbies));
        String arr[] = getResources().getStringArray(R.array.Hobbies);
        List<String> list = new ArrayList<String>();
        for (int i = 1; i < arr.length; i++) {
            list.add(arr[i]);
        }
        multiSpinner.setItems(list);
//        multiSpinner.setAdapter(mHobbiesAdapter);//mHobbiesSpinner
        multiSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mHobbies = getResources().getStringArray(R.array.Hobbies)[position];
                if (position != 0) {
                    hobbiesStr = mHobbies;
                    userMetadata.setHobbies(mHobbies);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        /*
        @Qualification Spinners
         */
        ArrayAdapter mBelow10thAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Below10th));
        mBelow10thSpinner.setAdapter(mBelow10thAdapter);
        mBelow10thSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mBelow10th = getResources().getStringArray(R.array.Below10th)[position];
                userMetadata.setBelow10TH(mBelow10th);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass10thAdapter = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class10th));
        m10thSpinner.setAdapter(mClass10thAdapter);
        m10thSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mClass10th = getResources().getStringArray(R.array.Class10th)[position];
                userMetadata.setClass10TH(mClass10th);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass12thAdapter1 = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class10th));
        m12thSpinner1.setAdapter(mClass12thAdapter1);
        m12thSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {//TODO
                String mClass12th1 = getResources().getStringArray(R.array.Class10th)[position];
                userMetadata.setClass12TH(mClass12th1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mClass12thAdapter2 = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.Class12th2));
        m12thSpinner2.setAdapter(mClass12thAdapter2);
        m12thSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mClass12th2 = getResources().getStringArray(R.array.Class12th2)[position];
                userMetadata.setmClass12th2(mClass12th2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mGraduationAdapter2 = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.CommonGraduation));
        mGraduationSpinner2.setAdapter(mGraduationAdapter2);
        mGraduationSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String graduationType = getResources().getStringArray(R.array.CommonGraduation)[position];
                userMetadata.setGraduationType(graduationType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter mPostGraduationAdapter2 = new ArrayAdapter<String>(
                RegistrationActivity.this,
                R.layout.spinner_item,
                getResources().getStringArray(R.array.CommonGraduation));
        mPostGraduationSpinner2.setAdapter(mPostGraduationAdapter2);

        mPostGraduationSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String postGraduationType = getResources().getStringArray(R.array.CommonGraduation)[position];
                userMetadata.setPostGraduationType(postGraduationType);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mPostGraduationSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String postGraduation = postGradServiceList.get(position).get_ID();
                userMetadata.setPostGraduation(postGraduation);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mGraduationSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String pGraduation = gradServiceList.get(position).get_ID();
                userMetadata.setGraduation(pGraduation);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
//Dynamic spinner data
        new CommonServiceExecuter("Occupation", "-1", mOccupationSpinner).execute();
        new PostGraduationServiceExecuter("Post", "-1", mPostGraduationSpinner1).execute();
        new GraduationServiceExecuter("Grad", "-1", mGraduationSpinner1).execute();
        new CommonServiceExecuter("Marital", "-1", mMaritalSpinner).execute();
//        new StateServiceExecuter("state", "-1", mStateSpinner).execute();

        mOccupationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String name = commonServiceList.get(position).get_Name();
                if (name.equalsIgnoreCase("Business")) {
                    depatrtmentandDesignationTextView.setText("Turn Over");
                } else if (name.equalsIgnoreCase("Student")) {
                    depatrtmentandDesignationTextView.setText("School Name");
                } else {
                    depatrtmentandDesignationTextView.setText("Department and Designation");
                }
                if(position>0){
                    detailofOccupationStr = commonServiceList.get(position).get_ID();
                    userMetadata.setDetailsOfOccupation(detailofOccupationStr);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mMaritalSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position!=0){
                    maritalStr = commonServiceList.get(position).get_ID();
                    userMetadata.setMaritalStatus(maritalStr);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mStateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (stateList != null && stateList.size() > 0) {
                    if(position!=0){
                        String UID = stateList.get(position).get_ID();
                        stateStr = UID;
                        userMetadata.setState(UID);
                        new DistrictServiceExecuter("district", UID, mDistrictSpinner).execute();
                    }else{
                        stateStr="";
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        mDistrictSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (districtList != null && districtList.size() > 0) {
                    if(position!=0){
                        String UID = districtList.get(position).get_ID();
                        districtStr = UID;
                        userMetadata.setDistrict(UID);
                    }else {
                        districtStr="";
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private class CommonServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public CommonServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(RegistrationActivity.this, "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            commonServiceList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(RegistrationActivity.this, result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }

    //

    private class GraduationServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public GraduationServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(RegistrationActivity.this, "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            gradServiceList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(RegistrationActivity.this, result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }


    private class PostGraduationServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public PostGraduationServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(RegistrationActivity.this, "Application", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            postGradServiceList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(RegistrationActivity.this, result);
            commonSpinnerView.setAdapter(commonAdapter);
        }
    }
    //

    private class StateServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public StateServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            stateList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            SpinnerAdapter commonAdapter = new SpinnerAdapter(RegistrationActivity.this, result);
            commonSpinnerView.setAdapter(commonAdapter);

        }
    }

    private class DistrictServiceExecuter extends AsyncTask<String, Void, List<CommonService>> {
        private String mRequestType = "";
        private String mSearchValue = "";
        private Spinner commonSpinnerView;

        public DistrictServiceExecuter(String requestType, String searchValue, Spinner view) {
            this.mRequestType = requestType;
            this.mSearchValue = searchValue;
            this.commonSpinnerView = view;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (progressDialog == null)
                progressDialog = ProgressDialog.show(RegistrationActivity.this, "District", "Configuring...", true, false);

        }

        @Override
        protected List<CommonService> doInBackground(String... urls) {
            List<CommonService> commonServicesData = new ArrayList<CommonService>();
            XMLParser parser = new XMLParser();
            commonServicesData = parser.commonServiceDataParser(mRequestType, mSearchValue);
            districtList = commonServicesData;
            return commonServicesData;
        }

        @Override
        protected void onPostExecute(List<CommonService> result) {
            if (progressDialog != null && progressDialog.isShowing())
                progressDialog.dismiss();
            progressDialog = null;
            SpinnerAdapter commonAdapter = new SpinnerAdapter(RegistrationActivity.this, result);
            commonSpinnerView.setAdapter(commonAdapter);

        }
    }
}
