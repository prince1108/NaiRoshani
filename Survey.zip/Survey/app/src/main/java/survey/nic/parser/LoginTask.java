package survey.nic.parser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

import survey.nic.com.survey.Constants;
import survey.nic.com.survey.LoginActivity;
import survey.nic.com.survey.MainActivity;
import survey.nic.utility.Util;

/**
 * Created by Ravi on 9/5/2016.
 */
public class LoginTask extends AsyncTask<String, Void, LoginMetaData> {
    private Context mContext;
    private String dataString = "";
    ProgressDialog progressDialog;
    private String PREFS_NAME = "NAIROSHANI";
    SharedPreferences mUserSettings;
    public LoginTask(Context context, String data) {
        this.mContext = context;
        this.dataString = data;
        mUserSettings = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = ProgressDialog.show(mContext, "Login", "Please wait...", true, false);
    }

    @Override
    protected LoginMetaData doInBackground(String... params) {
        String response = "";
        LoginMetaData loginMetaData=new LoginMetaData();
        BufferedReader reader = null;
        String KEY_PARENT_NODE = "row1";
        String KEY_ITEM_RESULT = "Result";
        String KEY_ITEM_REGNO = "Reg_no";
        String KEY_ITEM_UID = "uid";
        String KEY_ITEM_NAME = "name";
        String KEY_ITEM_PROFILE = "ProImage";
        System.out.println("Request====" + dataString);
        try {
            // Defined URL  where to send data
            URL url = new URL(Constants.loginServiceURL);
            // Send POST data request
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(dataString);
            wr.flush();
            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
            }
            response = sb.toString();
            System.out.println("Response====" + response);

            XMLParser xmlParser = new XMLParser();
            Document doc = xmlParser.getDomElement(response); // getting DOM element
            NodeList nl = doc.getElementsByTagName(KEY_PARENT_NODE);
            for (int i = 0; i < nl.getLength(); i++) {
                loginMetaData=new LoginMetaData();
                Element e = (Element) nl.item(i);
                String result = xmlParser.getValue(e, KEY_ITEM_RESULT);
                loginMetaData.setResult(result);
                String reg_id = xmlParser.getValue(e, KEY_ITEM_REGNO);
                loginMetaData.setReg_no(reg_id);
                String uid = xmlParser.getValue(e, KEY_ITEM_UID);
                loginMetaData.setUid(uid);
                String name = xmlParser.getValue(e, KEY_ITEM_NAME);
                loginMetaData.setName(name);
                String profileImage = xmlParser.getValue(e, KEY_ITEM_PROFILE);
                loginMetaData.setProfile(profileImage);
            }
        } catch (Exception ex) {

        } finally {
            try {
                reader.close();
            } catch (Exception ex) {
            }
        }
        // Show response on activity
        return loginMetaData;
    }

    @Override
    protected void onPostExecute(LoginMetaData s) {
        super.onPostExecute(s);
        progressDialog.dismiss();
        if(s.getResult().equalsIgnoreCase("1")){
            SharedPreferences.Editor editor;
            editor = mUserSettings.edit(); //2
            editor.putString("name", s.getName()); //3
            editor.putString("Reg_no", s.getReg_no()); //3
            editor.putString("uid", s.getUid()); //3
            editor.putString("ProImage", s.getProfile()); //3
            editor.commit(); //4
            mContext.startActivity(new Intent(mContext, MainActivity.class));
            ((Activity)mContext).finish();
        }
    }
}
